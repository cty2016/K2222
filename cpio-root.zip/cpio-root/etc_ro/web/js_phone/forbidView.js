function is2IpInSameSubnet(Ip1, Ip2, Netmask)
{
	var ip1_array = new Array();
	var ip2_array = new Array();
	var mask = new Array();
	ip1_array = Ip1.split('.');
	ip2_array = Ip2.split('.');
	mask = Netmask.split('.');

	for (var i = 0; i < 4; i++){
		if ( (ip1_array[i] & mask[i]) != (ip2_array[i] & mask[i]) )
			return false;
	}
	return true;
}

function validateKey(str)
{
	var str_item = str.split('.');
	for(var i=0; i<str_item.length; i++){
	   for (var j=0; j<str_item[i].length; j++) {
	    if (str_item[i].charAt(j) >= '0' && str_item[i].charAt(j) <= '9')
				continue;
		return 0;
	  }
	}
	return 1;
}

function checkDigitRange(str, num, min, max)
{
  var d = getDigit(str,num);
  if ( d > max || d < min )
      	return false;
  return true;
}

function getDigit(str, num)
{
  i=1;
  if ( num != 1 ) {
  	while (i!=num && str.length!=0) {
		if ( str.charAt(0) == '.' ) {
			i++;
		}
		str = str.substring(1);
  	}
  	if ( i!=num )
  		return -1;
  }
  for (i=0; i<str.length; i++) {
  	if ( str.charAt(i) == '.' ) {
		str = str.substring(0, i);
		break;
	}
  }
  if ( str.length == 0)
  	return -1;
  var d = parseInt(str, 10);
  return d;
}

function checkMask(str, num)
{
  var d = getDigit(str,num);
  if( !(d==0 || d==128 || d==192 || d==224 || d==240 || d==248 || d==252 || d==254 || d==255 ))
  	return false;
  return true;
}

function checkIpAddr(field)
{
	if(field.value.split(".").length != 4)
	{
		alert("IP地址：无效！");
		return false;
	}
	if (field.value == "") {
		alert("IP地址：不能为空。");
		return false;
	}
	if ( validateKey(field.value) == 0) {
		alert("IP地址：无效！");
		return false;
	}
	if ( !(checkDigitRange(field.value,1,1,223)) || (getDigit(field.value,1) ==127) ) {
		alert("IP地址：无效！");
		return false;
	}
	if ( !checkDigitRange(field.value,2,0,255) ) {
		alert("IP地址：无效！");
		return false;
	}
	if ( !checkDigitRange(field.value,3,0,255) ) {
		alert("IP地址：无效！");
		return false;
	}
	if ( !checkDigitRange(field.value,4,1,254) ) {
		alert("IP地址：无效！");
		return false;
	}
	return true;
}

function isValidMask(field)
{
	if(field.value.split(".").length != 4)
	{
		alert("子网掩码：无效！");
		return false;
	}
	if (field.value=="")
	{
	  	alert("子网掩码：不能为空。");
		return false;
  	}
	patrn =/^0{1,3}\.0{1,3}\.0{1,3}\.0{1,3}$/;//使用js正则表达式判断mask是否都为0
	if (patrn.exec(field.value))
	{
	    alert("子网掩码：无效！");
		return false;
	}

	if ( validateKey( field.value ) == 0 ) 
	{
		alert("子网掩码：无效！");
		return false;
	}
	
	if ( !checkMask(field.value,1) ) {
		return false;
	}
	
	if ( !checkMask(field.value,2) )
	{
		alert("子网掩码：无效！");
		return false;
	}
	
	if ( !checkMask(field.value,3) ) {
		alert("子网掩码：无效！");
		return false;
	}
	
	if ( !checkMask(field.value,4) ) {
		alert("子网掩码：无效！");
		return false;
	}

	if (! ( (getDigit(field.value,1) >= getDigit(field.value,2))
	&&  (getDigit(field.value,2) >= getDigit(field.value,3))
	&& (getDigit(field.value,3) >= getDigit(field.value,4)) ) )
	{
		alert("子网掩码：无效！");
		return false;
	}
	
	if((getDigit(field.value,4) != 0)
	&& ((getDigit(field.value,1) != 255)
	||(getDigit(field.value,2) != 255)
	||(getDigit(field.value,3) != 255)))
	{
		alert("子网掩码：无效！");
		return false;
	}
	
	if((getDigit(field.value,3) != 0)
	&& ((getDigit(field.value,1) != 255)
	||(getDigit(field.value,2) != 255)))
	{
		alert("子网掩码：无效！");
		return false;
	}

	if((getDigit(field.value,2) != 0) && (getDigit(field.value,1) != 255))
	{
		alert("子网掩码：无效！");
		return false;
	}
	return true;
}

function checkGatewayAddr(field)
{
	if(field.value.split(".").length != 4)
	{
		alert("默认网关：无效！");
		return false;
	}
	if (field.value == "") {
		alert("默认网关：不能为空！");
		return false;
	}

	if ( validateKey(field.value) == 0) {
		alert("默认网关：无效！");
		return false;
	}
	if ( !checkDigitRange(field.value,1,1,223) ) {
		alert("默认网关：无效！");
		return false;
	}
	if ( getDigit(field.value,1) ==127) {
		alert("默认网关：无效！");
		return false;
	
	}
	if ( !checkDigitRange(field.value,2,0,255) ) {
		alert("默认网关：无效！");
		return false;
	}
	if ( !checkDigitRange(field.value,3,0,255) ) {
		alert("默认网关：无效！");
		return false;
	}
	if ( !checkDigitRange(field.value,4,1,254) ) {
		alert("默认网关：无效！");
		return false;
	}
	return true;
}

function checkDNS(field)
{
	if(field.value.split(".").length != 4)
	{
		alert("首选DNS：无效！");
		return false;
	}
	if (field.value == "") {
		alert("首选DNS：不能为空！");
		return false;
	}
	if ( validateKey( field.value ) == 0 ) {
		alert("首选DNS：无效！");
		return false;
	}
	if ( !checkDigitRange(field.value,1,1,223) ) {
		alert("首选DNS：无效！");
		return false;
	}
	if ( getDigit(field.value,1) ==127)
	{
		alert("首选DNS：无效！");
		return false;
	}
	if ( !checkDigitRange(field.value,2,0,255) ) {
		alert("首选DNS：无效！");
		return false;
	}
	if ( !checkDigitRange(field.value,3,0,255) ) {
		alert("首选DNS：无效！");
		return false;
	}
	if ( !checkDigitRange(field.value,4,1,254) ) {
		alert("首选DNS：无效！");
		return false;
	}
	return true;
}

function checkPPPspechar(obj)
{
	var s = obj.value;
	for(var i = 0; i < s.length; i++) 
	{
	    if(s.charAt(i).match(/[\u0391-\uFFE5]/) || s.charAt(i).match(/[\u00B7]/)|| s.charAt(i).match(/[\u0022]/) 
			|| s.charAt(i).match(/[\u0026]/)|| s.charAt(i).match(/[\u0028]/)|| s.charAt(i).match(/[\u0029]/)
			|| s.charAt(i).match(/[\u003E]/) || s.charAt(i).match(/[\u003C]/)
			|| s.charAt(i).match(/[\u005C]/) || s.charAt(i).match(/[\u0027]/) || s.charAt(i).match(/[\u0025]/)
			|| s.charAt(i).match(/[\u007b]/) || s.charAt(i).match(/[\u007d]/) || s.charAt(i).match(/[\u003A]/)
			|| s.charAt(i).match(/[\u003B]/) || s.charAt(i).match(/[\u002C]/))
		{ 
			return false; 
		}
	}
	return true;
}

function checkPPPspechar2(obj)
{
	var s = obj.value;
	for(var i = 0; i < s.length; i++) 
	{
	    if(s.charAt(i).match(/[\u00B7]/)|| s.charAt(i).match(/[\u0022]/) 
			|| s.charAt(i).match(/[\u0026]/)|| s.charAt(i).match(/[\u0028]/)|| s.charAt(i).match(/[\u0029]/)
			|| s.charAt(i).match(/[\u003E]/) || s.charAt(i).match(/[\u003C]/)
			|| s.charAt(i).match(/[\u005C]/) || s.charAt(i).match(/[\u0027]/) || s.charAt(i).match(/[\u0025]/)
			|| s.charAt(i).match(/[\u007b]/) || s.charAt(i).match(/[\u007d]/) || s.charAt(i).match(/[\u003A]/)
			|| s.charAt(i).match(/[\u003B]/) || s.charAt(i).match(/[\u002C]/))
		{ 
			return false; 
		}
	}
	return true;
}

function checkspecialchar(obj)
{
	var s = obj.value;
	for(var i = 0; i < s.length; i++) 
	{
	    if(s.charAt(i).match(/[\u0391-\uFFE5]/) || s.charAt(i).match(/[\u00B7]/) || s.charAt(i).match(/[\u0022]/) 
			|| s.charAt(i).match(/[\u0026]/)|| s.charAt(i).match(/[\u0028]/)|| s.charAt(i).match(/[\u0029]/)
			|| s.charAt(i).match(/[\u003E]/) || s.charAt(i).match(/[\u003C]/)|| s.charAt(i).match(/[\u007e]/)
			|| s.charAt(i).match(/[\u005C]/) || s.charAt(i).match(/[\u0027]/) || s.charAt(i).match(/[\u0025]/)
			|| s.charAt(i).match(/[\u007b]/) || s.charAt(i).match(/[\u007d]/) || s.charAt(i).match(/[\u003A]/)
			|| s.charAt(i).match(/[\u003B]/) || s.charAt(i).match(/[\u002C]/))
		{ 
			return false; 
		}
	}
	return true;
}

function checkspecialchar2(obj)
{
	var s = obj.value;
	for(var i = 0; i < s.length; i++) 
	{
	    if(s.charAt(i).match(/[\u00B7]/)|| s.charAt(i).match(/[\u0022]/) 
			|| s.charAt(i).match(/[\u0026]/)|| s.charAt(i).match(/[\u0028]/)|| s.charAt(i).match(/[\u0029]/)
			|| s.charAt(i).match(/[\u003E]/) || s.charAt(i).match(/[\u003C]/)|| s.charAt(i).match(/[\u007e]/)
			|| s.charAt(i).match(/[\u005C]/) || s.charAt(i).match(/[\u0027]/) || s.charAt(i).match(/[\u0025]/)
			|| s.charAt(i).match(/[\u007b]/) || s.charAt(i).match(/[\u007d]/) || s.charAt(i).match(/[\u003A]/)
			|| s.charAt(i).match(/[\u003B]/) || s.charAt(i).match(/[\u002C]/))
		{
			return false; 
		}
	}
	return true;
}

function checkHex(str)
{
	var len = str.length;

	for (var i=0; i<str.length; i++) {
		if ((str.charAt(i) >= '0' && str.charAt(i) <= '9') ||
			(str.charAt(i) >= 'a' && str.charAt(i) <= 'f') ||
			(str.charAt(i) >= 'A' && str.charAt(i) <= 'F') ){
				continue;
		}else
	        return false;
	}
    return true;
}

function getStrByteLen(obj)
{ 
     var len = 0; 
	 str = obj.value;
     for (var i = 0; i < str.length; i++) 
	 { 
         if (str.charAt(i).match(/[\u0391-\uFFE5]/))
            len += 3; 
         else
             len += 1; 
     } 
     if (len > 32)
	 {
		return false;
     } 
     return true;
}
