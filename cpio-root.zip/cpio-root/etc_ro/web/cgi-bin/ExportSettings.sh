#!/bin/sh

CONF=Default
cd /tmp

#output HTTP header
echo "Pragma: no-cache\n"
echo "Cache-control: no-cache\n"
echo "Content-type: application/octet-stream"
echo "Content-Transfer-Encoding: binary"	
echo "Content-Disposition: attachment; filename=\"config.dat\""
echo ""

nvram show >> ${CONF} 2>/dev/null
CRC=`cksum ${CONF} 2>/dev/null`

echo "#The following line must not be removed."
echo "#ID "${CRC}
cat ${CONF}
rm -f ${CONF} 2>/dev/null