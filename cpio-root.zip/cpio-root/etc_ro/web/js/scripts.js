
(function() {
    "use strict";

    // custom scrollbar

    /* K2_V2 body no right roller by xichen 160513 */
    /* $("html").niceScroll({styler:"fb",cursorcolor:"#65cea7", cursorwidth: '6', cursorborderradius: '0px', background: '#424f63', spacebarenabled:false, cursorborder: '0',  zindex: '1000'}); */

    $(".main-content").niceScroll({styler:"fb",cursorcolor:"#F08300", cursorwidth: '3', cursorborderradius: '0px', spacebarenabled:false, cursorborder: '0'});

    $(".home-content").niceScroll({styler:"fb", horizrailenabled:false, cursorcolor:"#F08300", cursorwidth: '3', cursorborderradius: '0px', spacebarenabled:false, cursorborder: '0', overflowx:false, overflowy:true});

	$(".main-content").mouseover(function(){
        $(".main-content").getNiceScroll().resize();
	});

    function mainContentHeightAdjust() {
      // Adjust main content height
       var docHeight = jQuery(document).height();
       if(docHeight > jQuery('.main-content').height())
          jQuery('.main-content').height(docHeight);
    }

   // Menu Toggle
   jQuery('.toggle-btn').click(function(){
   	   /* K2_V2 why hide left side, don't know by xichen 160513 */
       /*$(".left-side").getNiceScroll().hide();

       if ($('body').hasClass('left-side-collapsed')) {
           $(".left-side").getNiceScroll().hide();
       }*/
      var body = jQuery('body');
      var bodyposition = body.css('position');

      if(bodyposition != 'relative') {

         if(!body.hasClass('left-side-collapsed')) {
            body.addClass('left-side-collapsed');
            jQuery('.custom-nav ul').attr('style','');

            jQuery(this).addClass('menu-collapsed');

         } else {
            body.removeClass('left-side-collapsed chat-view');
            jQuery('.custom-nav li.active ul').css({display: 'block'});

            jQuery(this).removeClass('menu-collapsed');

         }
      } else {
         if(body.hasClass('left-side-show'))
            body.removeClass('left-side-show');
         else
            body.addClass('left-side-show');
         /* K2_V2 should not change maincontent height by xichen 160513 */
         /* mainContentHeightAdjust(); */
      }

   });
   

   searchform_reposition();

   jQuery(window).resize(function(){

      if(jQuery('body').css('position') == 'relative') {

         jQuery('body').removeClass('left-side-collapsed');

      } else {

         jQuery('body').css({left: '', marginRight: ''});
      }

      searchform_reposition();

   });

   function searchform_reposition() {
      if(jQuery('.searchform').css('position') == 'relative') {
         jQuery('.searchform').insertBefore('.left-side-inner .logged-user');
      } else {
         jQuery('.searchform').insertBefore('.menu-right');
      }
   }

    // panel collapsible
    $('.panel .tools .fa').click(function () {
        var el = $(this).parents(".panel").children(".panel-body");
        if ($(this).hasClass("fa-chevron-down")) {
            $(this).removeClass("fa-chevron-down").addClass("fa-chevron-up");
            el.slideUp(200);
        } else {
            $(this).removeClass("fa-chevron-up").addClass("fa-chevron-down");
            el.slideDown(200); }
    });

    $('.todo-check label').click(function () {
        $(this).parents('li').children('.todo-title').toggleClass('line-through');
    });

    $(document).on('click', '.todo-remove', function () {
        $(this).closest("li").remove();
        return false;
    });

    $("#sortable-todo").sortable();


    // panel close
    $('.panel .tools .fa-times').click(function () {
        $(this).parents(".panel").parent().remove();
    });



    // tool tips

    $('.tooltips').tooltip();

    // popovers

    $('.popovers').popover();

})(jQuery);


	/* header */
	
    $("#user_ul").mouseover(function(){

	});
	var path = window.location.pathname;
	var url = path.substr(path.lastIndexOf("\/")+1);
	if (url == "index.asp")
	    $("#home_href").addClass('active');
	else if (url == "wanset.asp")
	    $("#wizard_href").addClass('active');
	else if (url == "ipctr.asp")
	    $("#device_href").addClass('active');
	else if (url == "status.asp")
	    $("#advance_href").addClass('active');
	else
	    $("#advance_href").addClass('active');

function showUrl(url, ifname)
{			
	window.location.href = url + '?fx=' + Math.random();
}
function iFrameHeight() 
{ 
	var ifm= document.getElementById("iframepage"); 
	var subWeb = document.frames ? document.frames["formframe"].document : ifm.contentDocument; 
	if(ifm != null && subWeb != null) 
	{ 
		if(subWeb.body.scrollHeight<800)
			ifm.height = 800; 
		else
			ifm.height = subWeb.body.scrollHeight;
	} 
}
function showUrl_head(url,name)
{
	var ifm= document.getElementById("iframepage_head");
	$("#iframepage_head").show();
	$("#left_div").hide(); 
	//ifm.height = 600;
	url=url+"?t="+(new Date().getTime());
	window.open(url,name);
	
}
function iFrameHeight_head() 
{ 
	var ifm= document.getElementById("iframepage_head"); 
	var subWeb = document.frames ? document.frames["formframe_head"].document : ifm.contentDocument; 
	if(ifm != null && subWeb != null) 
	{ 
		if(subWeb.body.scrollHeight<800)
			ifm.height = 800; 
		else
			ifm.height = subWeb.body.scrollHeight;
	} 
}

var currentVersion;    //当前软件版本
var newVersion;        //最新软件版本
var swPt;              //发布日期
var sw_verdesc;	
var err_num = 0;
var warn_num = 0;
var router_frac = 100;
var test_complete = 0;
var err_complete = 0;
var warn_complete = 0;
var onekeycheck_stop;
var realstop;
var opmode = "<% getCfgZero(1, "sw_mode_ex"); %>";
function fun_sys_error_wanstatus()
{
	$.ajax({
	type: "GET",
	url: "/goform/gra_UpdateCheck",
	error: function(request) {
	},
	success: function(date){

		}
	});	
	
	$.ajax({
	type: "GET",
	url: "/goform/gra_WanLinkCheck",
	error: function(request) {
	},
	success: function(date){
			var WanLink_json = eval("("+date+")");  
			if(WanLink_json["WanLink"] == 1)
			{
				$("#onekeycheck_wanstatus").show();
				$("#onekeycheck_wanstatus_ok").show();
				onekeycheck_stop = setTimeout("fun_sys_error_internet()", 1000);
				 
			}
			else
			{
				
				if(opmode == "8")
				{
					$("#onekeycheck_wanstatus").show();
					$("#onekeycheck_wanstatus_ok").show();
					onekeycheck_stop = setTimeout("fun_sys_error_internet()", 1000);
				}
				else
				{
					$("#onekeycheck_wanstatus").show();
					$("#onekeycheck_wanstatus_fail").show();  //WAN口未连接
					err_num = err_num + 1;
					router_frac = router_frac - 30;
					$("#onekeycheck_real_score").html(router_frac);
					onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
				}
				
				 
			}
		}
	});	
}

function fun_sys_error_internet()
{
	$.ajax({
	type: "GET",
	url: "/goform/gra_InternetCheck",
	error: function(request) {
	},
	success: function(date){
			var Internet_json = eval("("+date+")");  
			if(Internet_json["PingQQ"] == 1)
			{
				//可以Ping通QQ
				$("#onekeycheck_internet").show();
				$("#onekeycheck_internet_ok").show();
				onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
			}
			else  //不可以Ping通QQ
			{
				if(Internet_json["NetworkType"] == 2)  //静态IP问题
				{
					$("#onekeycheck_internet_fail_error").html("静态IP设置有问题，静态IP上网方式有别于自动方式（DHCP）和宽带拨号上网方式，使用前请确认当前网络是否是静态IP网络，如果是，请向网络管理员核实IP地址、子网掩码、网关、首选DNS、备用DNS等参数");
					$("#onekeycheck_internet").show();
					$("#onekeycheck_internet_fail").show();  //静态IP问题
					err_num = err_num + 1;
					router_frac = router_frac - 15;
					$("#onekeycheck_real_score").html(router_frac);
					onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
					 
				}
				else if(Internet_json["NetworkType"] == 1) //PPPOE问题
				{
					if(Internet_json["WanIp"] == 0)   //WAN口无IP
					{
						if(Internet_json["ErrorCode"] == 709)
						{
							$("#onekeycheck_internet_fail_error").html("宽带密码太短或者与可能与以前使用的密码不匹配，请联系宽带运营商");
							$("#onekeycheck_internet").show();
							$("#onekeycheck_internet_fail").show();  //PPPOE密码太短或者不匹配
							err_num = err_num + 1;
							
							router_frac = router_frac - 15;
							$("#onekeycheck_real_score").html(router_frac);
							onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
							 
						}
						else if(Internet_json["ErrorCode"] == 691)
						{
							$("#onekeycheck_internet_fail_error").html("账号密码错误或账号已欠费，请确认后重新输入！");
							$("#onekeycheck_internet").show();
							$("#onekeycheck_internet_fail").show();  //PPPOE密码错误或者账号到期
							err_num = err_num + 1;
							
							router_frac = router_frac - 15;
							$("#onekeycheck_real_score").html(router_frac);
							onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
							 
						}
						else if(Internet_json["ErrorCode"] == 678)
						{
							$("#onekeycheck_internet_fail_error").html("账号密码错误或账号已欠费，请确认后重新输入！");
							$("#onekeycheck_internet").show();
							$("#onekeycheck_internet_fail").show();  //运营商服务器升级或者网线松动
							err_num = err_num + 1;
							 	
							router_frac = router_frac - 15;
							$("#onekeycheck_real_score").html(router_frac);
							onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
							 
						}
						else if(Internet_json["ErrorCode"] == 646 || Internet_json["ErrorCode"] == 647 || Internet_json["ErrorCode"] == 648 || Internet_json["ErrorCode"] == 649)
						{
							$("#onekeycheck_internet_fail_error").html("您的宽带账号无法使用，请联系宽带运营商");
							$("#onekeycheck_internet").show();
							$("#onekeycheck_internet_fail").show();  //PPPOE账号无法使用，错误代码XXX
							err_num = err_num + 1;
							 	
							router_frac = router_frac - 15;
							$("#onekeycheck_real_score").html(router_frac);
							onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
							 
						}
						else if(Internet_json["ErrorCode"] == 1)
						{
							$("#onekeycheck_internet_fail_error").html("正在拨号");
							$("#onekeycheck_internet").show();
							$("#onekeycheck_internet_fail").show();  //PPPOE正在拨号
							err_num = err_num + 1;
							 	
							router_frac = router_frac - 15;
							$("#onekeycheck_real_score").html(router_frac);
							onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
							 
						}
						else
						{
							$("#onekeycheck_internet_fail_error").html("PPPoE请求发出后无响应，可能由于宽带运营商线路不稳定，导致路由器PPPoE拨号异常，请联系宽带运营商");
							$("#onekeycheck_internet").show();
							$("#onekeycheck_internet_fail").show();  //PPPOE请求发出无响应
							err_num = err_num + 1;
							 	
							router_frac = router_frac - 15;
							$("#onekeycheck_real_score").html(router_frac);
							onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
							 
						}
					}
					else   //WAN口有IP
					{
						if(Internet_json["PingWan"] == 0)  //不能PING通WAN侧网关IP
						{
							$("#onekeycheck_internet_fail_error").html("1.请重启宽带运营商设备，如依然无法解决，请联系宽带运营商；2.请尝试开启路由器MAC克隆功能，克隆能上网的设备MAC地址");
							$("#onekeycheck_internet").show();
							$("#onekeycheck_internet_fail").show();  //重启或MAC克隆
							err_num = err_num + 1;
							 
							router_frac = router_frac - 15;
							$("#onekeycheck_real_score").html(router_frac);
							onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
							 
						}
						else  //能PING通WAN侧网关IP
						{
							if(Internet_json["DNS"] == 0)
							{
								$("#onekeycheck_internet_fail_error").html("无DNS，请至外网设置页面设置DNS");
								$("#onekeycheck_internet").show();
								$("#onekeycheck_internet_fail").show();  //DNS地址不存在
								err_num = err_num + 1;
								 
								router_frac = router_frac - 15;
								$("#onekeycheck_real_score").html(router_frac);
								onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
								 
							}
							else if(Internet_json["DNS"] == 1)
							{
								$("#onekeycheck_internet_fail_error").html("1.路由器WAN侧连接的宽带运营商设备无法上网，请重启宽带运营商设备，如依然存在问题，请联系宽带运营商；2.请尝试开启路由器MAC克隆功能，克隆能上网的设备MAC地址");
								$("#onekeycheck_internet").show();
								$("#onekeycheck_internet_fail").show();  // DNS地址存在
								err_num = err_num + 1;
								 
								router_frac = router_frac - 15;
								$("#onekeycheck_real_score").html(router_frac);
								onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
								 
							}
							else
							{
								$("#onekeycheck_internet_fail_error").html("路由器使用了自定义DNS，可能会影响上网效果，如果已经影响上网，建议取消自定义DNS，如果上网没影响，可以忽略本条建议");
								$("#onekeycheck_internet").show();
								$("#onekeycheck_internet_fail").show();  // DNS地址自定义
								err_num = err_num + 1;
								 
								router_frac = router_frac - 15;
								$("#onekeycheck_real_score").html(router_frac);
								onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
								 
							}
						}
					}
				}
				else   //DHCP问题
				{
					if(Internet_json["WanIp"] == 0)  //WAN口无IP
					{
						$("#onekeycheck_internet_fail_error").html("自动方式（DHCP）无法上网，请确认上联设备是否打开DHCP服务");
						$("#onekeycheck_internet").show();
						$("#onekeycheck_internet_fail").show();  //DHCP问题
						err_num = err_num + 1;
						 
						router_frac = router_frac - 15;
						$("#onekeycheck_real_score").html(router_frac);
						onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
						 
					}
					else   //WAN口有IP
					{
						if(Internet_json["PingWan"] == 0)  //不能PING通WAN侧网关IP
						{
							$("#onekeycheck_internet_fail_error").html("1.请重启宽带运营商设备，如依然无法解决，请联系宽带运营商；2.请尝试开启路由器MAC克隆功能，克隆能上网的设备MAC地址");
							$("#onekeycheck_internet").show();
							$("#onekeycheck_internet_fail").show();  //重启或MAC克隆
							err_num = err_num + 1;
							 
							router_frac = router_frac - 15;
							$("#onekeycheck_real_score").html(router_frac);
							onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
							 
						}
						else  //能PING通WAN侧网关IP
						{
							if(Internet_json["DNS"] == 0)
							{
								$("#onekeycheck_internet_fail_error").html("无DNS，请至外网设置页面设置DNS");
								$("#onekeycheck_internet").show();
								$("#onekeycheck_internet_fail").show();  //DNS地址不存在
								err_num = err_num + 1;
								 
								router_frac = router_frac - 15;
								$("#onekeycheck_real_score").html(router_frac);
								onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
								 
							}
							else if(Internet_json["DNS"] == 1)
							{
								$("#onekeycheck_internet_fail_error").html("1.路由器WAN侧连接的宽带运营商设备无法上网，请重启宽带运营商设备，如依然存在问题，请联系宽带运营商；2.请尝试开启路由器MAC克隆功能，克隆能上网的设备MAC地址");
								$("#onekeycheck_internet").show();
								$("#onekeycheck_internet_fail").show();  // DNS地址存在
								err_num = err_num + 1;
								 
								router_frac = router_frac - 15;
								$("#onekeycheck_real_score").html(router_frac);
								onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
								 
							}
							else
							{
								$("#onekeycheck_internet_fail_error").html("路由器使用了自定义DNS，可能会影响上网效果，如果已经影响上网，建议取消自定义DNS，如果上网没影响，可以忽略本条建议");
								$("#onekeycheck_internet").show();
								$("#onekeycheck_internet_fail").show();  // DNS地址自定义
								err_num = err_num + 1;
								 
								router_frac = router_frac - 15;
								$("#onekeycheck_real_score").html(router_frac);
								onekeycheck_stop = setTimeout("fun_sys_error_wireless()", 1500);
								 
							}
						}
					}
				}
			}
		}
	});	
}

function fun_sys_error_wireless()
{
	$("#onekeycheck_warn").show();
	
	$.ajax({
	type: "GET",
	url: "/goform/gra_WIFICheck",
	error: function(request) {
	},
	success: function(date){
			var WIFI_json = eval("("+date+")"); 
			$("#onekeycheck_wireless").show(); 
			if(WIFI_json["24GLink"] == 0)
			{
				$("#onekeycheck_wireless_fail_2G").show(); //2.4G无线未开启
				warn_num = warn_num + 1;
				router_frac = router_frac - 10;
				$("#onekeycheck_real_score").html(router_frac);
				  
			}
			else
			{
				//2.4G无线开启

			}
			if(WIFI_json["5GLink"] == 0)
			{
				$("#onekeycheck_wireless_fail_5G").show();  //5G无线未开启
				warn_num = warn_num + 1;
				router_frac = router_frac - 10;
				$("#onekeycheck_real_score").html(router_frac);
				  
			}
			else
			{
				//5G无线开启
			}
			if(WIFI_json["24GSignalEnhancement"] == 0)
			{
				$("#onekeycheck_wireless_fail_enchancement").show();   //2.4G信号增强未开启
				warn_num = warn_num + 1;
				  
				router_frac = router_frac - 10;
				$("#onekeycheck_real_score").html(router_frac);
				onekeycheck_stop = setTimeout("fun_sys_error_wifi_pwd()", 1500);
				 
			}
			else
			{
				//2.4G信号增强开启
				onekeycheck_stop = setTimeout("fun_sys_error_wifi_pwd()", 1500);
				 
			}
			if(WIFI_json["24GLink"] == 1 && WIFI_json["5GLink"] == 1 && WIFI_json["24GSignalEnhancement"] == 1)
			{
				$("#onekeycheck_wireless_ok").show();
			}
		}
	});	
}

function fun_sys_error_wifi_pwd()
{
	$.ajax({
	type: "GET",
	url: "/goform/gra_WifiPasswordCheck",
	error: function(request) {
	},
	success: function(date){
			var WifiPassword_json = eval("("+date+")");
			$("#onekeycheck_wifi_pwd").show();
			if(WifiPassword_json["24GWIFISecurity"] == 1)
			{
				$("#onekeycheck_wifi_pwd_fail_2G_error").html("2.4G密码：安全性弱");
				$("#onekeycheck_wifi_pwd_fail_2G").show();   //2.4G无线密码安全性弱
				warn_num = warn_num + 1;
				 
				router_frac = router_frac - 9;
				$("#onekeycheck_real_score").html(router_frac);
			}
			else if(WifiPassword_json["24GWIFISecurity"] == 2)
			{
				$("#onekeycheck_wifi_pwd_fail_2G_error").html("2.4G密码：安全性中");
				$("#onekeycheck_wifi_pwd_fail_2G").show();   //2.4G无线密码安全性中
				warn_num = warn_num + 1;
				 
				router_frac = router_frac - 5;
				$("#onekeycheck_real_score").html(router_frac);
			}
			else
			{
				//2.4G无线密码安全性强
			}
			if(WifiPassword_json["5GWIFISecurity"] == 1)
			{
				$("#onekeycheck_wifi_pwd_fail_5G_error").html("5G密码：安全性弱");
				$("#onekeycheck_wifi_pwd_fail_5G").show();   //5G无线密码安全性弱
				warn_num = warn_num + 1;
				 
				router_frac = router_frac - 9;
				$("#onekeycheck_real_score").html(router_frac);
				onekeycheck_stop = setTimeout("fun_sys_error_router_pwd()", 1500);
				 
			}
			else if(WifiPassword_json["5GWIFISecurity"] == 2)
			{
				$("#onekeycheck_wifi_pwd_fail_5G_error").html("5G密码：安全性中");
				$("#onekeycheck_wifi_pwd_fail_5G").show();   //5G无线密码安全性中
				warn_num = warn_num + 1;
				 
				router_frac = router_frac - 5;
				$("#onekeycheck_real_score").html(router_frac);
				onekeycheck_stop = setTimeout("fun_sys_error_router_pwd()", 1500);
				 
			}
			else
			{
				//5G无线密码安全性强
				onekeycheck_stop = setTimeout("fun_sys_error_router_pwd()", 1500);
				 
			}
			if(WifiPassword_json["24GWIFISecurity"] == 3 && WifiPassword_json["5GWIFISecurity"] == 3)
			{
				
				$("#onekeycheck_wifi_pwd_ok").show();
			}
		}
	});	
}

function fun_sys_error_router_pwd()
{
	$.ajax({
	type: "GET",
	url: "/goform/gra_RouterPasswordCheck",
	error: function(request) {
	},
	success: function(date){
			var RouterPassword_json = eval("("+date+")");
			if(RouterPassword_json["RouterSecurity"] == 1)
			{
				$("#onekeycheck_router_pwd_fail_error").html("路由器密码：安全性弱");
				$("#onekeycheck_router_pwd_fail").show();
				$("#onekeycheck_router_pwd").show();   //登录密码安全性弱
				warn_num = warn_num + 1;
				 
				router_frac = router_frac - 9;
				$("#onekeycheck_real_score").html(router_frac);
				onekeycheck_stop = setTimeout("fun_sys_error_sw()", 1500);
				 
			}
			else if(RouterPassword_json["RouterSecurity"] == 2)
			{
				$("#onekeycheck_router_pwd_fail_error").html("路由器密码：安全性中");
				$("#onekeycheck_router_pwd_fail").show();
				$("#onekeycheck_router_pwd").show();   //登录密码安全性中
				warn_num = warn_num + 1;
				 
				router_frac = router_frac - 5;
				$("#onekeycheck_real_score").html(router_frac);
				onekeycheck_stop = setTimeout("fun_sys_error_sw()", 1500);
				 
			}
			else
			{
				//登录密码安全性强
				$("#onekeycheck_router_pwd").show();
				$("#onekeycheck_router_pwd_ok").show();
				onekeycheck_stop = setTimeout("fun_sys_error_sw()", 1500);
				 
			}
		}
	});	
}

function fun_sys_error_sw()
{
	$.ajax({
	type: "GET",
	url:'get_software_ver.asp?t=' + Math.random(),
	error: function(request) {
	},
	success: function(date){
			if(date.split(',')[1] == 1)
			{
				$("#onekeycheck_sw").show();   //有新版本
				$("#onekeycheck_sw_fail").show();   
				warn_num = warn_num + 1;
				
				router_frac = router_frac - 10;
				$("#onekeycheck_real_score").html(router_frac);
			}
			else
			{
				$("#onekeycheck_sw").show();   //没有新版本
				$("#onekeycheck_sw_ok").show();
			}
			if(err_num == 0 && warn_num == 0)
			{
				$("#onekeycheck_restart").show();
				$("#onekeycheck_on").show();
				$("#onekeycheck_done").show();
				$("#onekeycheck_on").html("系统安全，请放心使用");
				$("#sys_error").hide();
				$("#sys_warn").hide();
				$("#sys_noerr").show();
			}
			else
			{
				$("#onekeycheck_restart").show();
				$("#onekeycheck_on").show();
				$("#onekeycheck_done").show();
				$("#onekeycheck_on").html("发现"+err_num+"个故障，"+warn_num+"个提醒，建议立即修复");
			}
			wan_num = router_frac + 15;
			test_complete = 1;
			err_complete = err_num -1;
			warn_complete = warn_num;
			currentVersion = date.split(',')[3];    //当前软件版本
			newVersion = date.split(',')[4];        //最新软件版本
			swPt = date.split(',')[5];              //发布日期
			sw_verdesc = date.split(',')[6];
			err_num = 0;
			warn_num = 0;
			router_frac = 100;
		}
	});	
}

function startOneCheck()
{
	currentVersion = "";    //当前软件版本
	newVersion = "";        //最新软件版本
 	swPt = "";              //发布日期
	sw_verdesc = "";	
	err_num = 0;
	warn_num = 0;
	router_frac = 100;
	test_complete = 0;
	err_complete = 0;
	warn_complete = 0;

	clearTimeout(realstop);
	clearTimeout(onekeycheck_stop);
	
	$("#onekeycheck_on").html("体检进行中......");
	$("#onekeycheck_real_score").html("100");
	$("#onekeycheck_title_div").hide();
	$("#onekeycheck_header_score_div").show();
	$("#onekeycheck_start").hide();
	$("#onekeycheck_restart").hide();
	$("#onekeycheck_real_score").show();
	
	$("#onekeycheck_on").show();
	$("#onekeycheck_done").show();
	//trouble
	$("#onekeycheck_trouble").show();
	//wan status
	$("#onekeycheck_wanstatus").hide();
	$("#onekeycheck_wanstatus_ok").hide();
	$("#onekeycheck_wanstatus_fail").hide();
	//internet check
	$("#onekeycheck_internet").hide();
	$("#onekeycheck_internet_ok").hide();
	$("#onekeycheck_internet_fail").hide();
	//warning
	$("#onekeycheck_warn").hide();
	//wireless status
	$("#onekeycheck_wireless").hide();
	$("#onekeycheck_wireless_ok").hide();
	$("#onekeycheck_wireless_fail_2G").hide();
	$("#onekeycheck_wireless_fail_5G").hide();
	//wifi password
	$("#onekeycheck_wifi_pwd").hide();
	$("#onekeycheck_wifi_pwd_ok").hide();
	$("#onekeycheck_wifi_pwd_fail_2G").hide();
	$("#onekeycheck_wifi_pwd_fail_5G").hide();
	//router password
	$("#onekeycheck_router_pwd").hide();
	$("#onekeycheck_router_pwd_ok").hide();
	$("#onekeycheck_router_pwd_fail").hide();
	//onekey check
	$("#onekeycheck_sw").hide();
	$("#onekeycheck_sw_ok").hide();
	$("#onekeycheck_sw_fail").hide();
	
	test_complete = 0;
	onekeycheck_stop = setTimeout("fun_sys_error_wanstatus()", 500);
	 
	return;
}

function showOneKey()
{
	clearTimeout(onekeycheck_stop);
	$("#onekeycheck_title_div").show();
	$("#onekeycheck_header_score_div").hide();
	$("#onekeycheck_start").show();
	$("#onekeycheck_restart").hide();
	$("#onekeycheck_real_score").hide();
	
	$("#onekeycheck_on").hide();
	$("#onekeycheck_done").hide();
	//trouble
	$("#onekeycheck_trouble").hide();
	//wan status
	$("#onekeycheck_wanstatus").hide();
	$("#onekeycheck_wanstatus_ok").hide();
	$("#onekeycheck_wanstatus_fail").hide();
	//internet check
	$("#onekeycheck_internet").hide();
	$("#onekeycheck_internet_ok").hide();
	$("#onekeycheck_internet_fail").hide();
	//warning
	$("#onekeycheck_warn").hide();
	//wireless status
	$("#onekeycheck_wireless").hide();
	$("#onekeycheck_wireless_ok").hide();
	$("#onekeycheck_wireless_fail_2G").hide();
	$("#onekeycheck_wireless_fail_5G").hide();
	//wifi password
	$("#onekeycheck_wifi_pwd").hide();
	$("#onekeycheck_wifi_pwd_ok").hide();
	$("#onekeycheck_wifi_pwd_fail_2G").hide();
	$("#onekeycheck_wifi_pwd_fail_5G").hide();
	//router password
	$("#onekeycheck_router_pwd").hide();
	$("#onekeycheck_router_pwd_ok").hide();
	$("#onekeycheck_router_pwd_fail").hide();
	//onekey check
	$("#onekeycheck_sw").hide();
	$("#onekeycheck_sw_ok").hide();
	$("#onekeycheck_sw_fail").hide();
	return;
}

function restartOnekeyCheck()
{
	startOneCheck();
}
function realstopOnekeyCheck()
{
	window.clearTimeout(onekeycheck_stop);
}

function stopOnekeyCheck()
{
	clearTimeout(onekeycheck_stop);
	realstop = setTimeout("realstopOnekeyCheck()", 2000);
	return;
}

function reloadWanStatus()
{
	//alert("test_complete=" + test_complete);
	if(test_complete == 1)
	{
		$.ajax({
		type: "GET",
		url: "/goform/gra_checkWAN",
		error: function(request) {
		},
		success: function(date){
				if(date==1)
				{
					$("#onekeycheck_wanstatus_fail").hide();
					$("#onekeycheck_wanstatus_ok").show();
					$("#onekeycheck_real_score").html(wan_num);
					$("#onekeycheck_on").html("发现"+err_complete+"个故障，"+warn_complete+"个提醒，建议立即修复");
				}
				else
				{
					$("#onekeycheck_wanstatus_fail").show();
					$("#onekeycheck_wanstatus_ok").hide();
				}
			}
		});	
	}
}

function isAllEngAndNum(str)
{
	for (var i=0; i<str.length; i++){
		if((str.charAt(i) >= 'a' && str.charAt(i) <= 'z') || (str.charAt(i) >= 'A' && str.charAt(i) <= 'Z') ||
			(str.charAt(i) >= '0' && str.charAt(i) <= '9') || (str.charAt(i) == '_'))
			continue;
		return false;
	}
	return true;
}

/* added by xichen 141117 for forbidden get js/forbidView.s source code without login */
//document.write('<script type="text/javascript" src="js/forbidView.js?r='+new Date().getTime()+'"><\/script>');
var base64EncodeChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var base64DecodeChars = new Array(
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63,
    52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1,
    -1,  0,  1, 2,  3,  4,  5,  6,  7,  8,  9,  10, 11, 12, 13, 14,
    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1,
    -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1);
function base64encode(str) {
    var out, i, len;
    var c1, c2, c3;
    len = str.length;
    i = 0;
    out = "";
    while(i < len) {
 c1 = str.charCodeAt(i++) & 0xff;
 if(i == len)
 {
     out += base64EncodeChars.charAt(c1 >> 2);
     out += base64EncodeChars.charAt((c1 & 0x3) << 4);
     out += "==";
     break;
 }
 c2 = str.charCodeAt(i++);
 if(i == len)
 {
     out += base64EncodeChars.charAt(c1 >> 2);
     out += base64EncodeChars.charAt(((c1 & 0x3)<< 4) | ((c2 & 0xF0) >> 4));
     out += base64EncodeChars.charAt((c2 & 0xF) << 2);
     out += "=";
     break;
 }
 c3 = str.charCodeAt(i++);
 out += base64EncodeChars.charAt(c1 >> 2);
 out += base64EncodeChars.charAt(((c1 & 0x3)<< 4) | ((c2 & 0xF0) >> 4));
 out += base64EncodeChars.charAt(((c2 & 0xF) << 2) | ((c3 & 0xC0) >>6));
 out += base64EncodeChars.charAt(c3 & 0x3F);
    }
    return out;
}

function utf16to8(str) {
    var out, i, len, c;
    out = "";
    len = str.length;
    for(i = 0; i < len; i++) {
 c = str.charCodeAt(i);
 if ((c >= 0x0001) && (c <= 0x007F)) {
     out += str.charAt(i);
 } else if (c > 0x07FF) {
     out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
     out += String.fromCharCode(0x80 | ((c >>  6) & 0x3F));
     out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
 } else {
     out += String.fromCharCode(0xC0 | ((c >>  6) & 0x1F));
     out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
 }
    }
    return out;
}
/* end */

function oldadmpassonfocus()
{
	$("#oldadmpasslable").hide();
}

function admpassonfocus()
{
	$("#admpasslable").hide();
}

function admpass2ndonfocus()
{
     $("#admpass2ndlable").hide();
}

function changepassword()
{
        var http_username = "<% getCfgGeneral(1, "http_username"); %>"
		var http_passwd = "<% getCfgGeneral(1, "http_passwd"); %>";
		document.Adm.admuser.value = http_username;
        var flags = "0";
		
		var oldadminpass = document.getElementById("oldadmpass").value;
		var newadmpass = document.getElementById("admpass_new").value;
		var newadmpass2nd = document.getElementById("admpass2nd_new").value;
		var oldadminpasscode = base64encode(utf16to8(oldadminpass));
		
		if ( oldadminpasscode != http_passwd) {
			$("#oldadmpasslable").attr("title","原密码错误！");
			$("#oldadmpasslable").html("原密码错误！"); 
			$("#oldadmpasslable").show();
			flags = "1";
		}
	
		if(newadmpass == '') {
			$("#admpasslable").attr("title","新密码不能为空！");
			$("#admpasslable").html("新密码不能为空！"); 
			$("#admpasslable").show();
			flags = "0";
			return false;
		}
		
		if((document.getElementById("admpass_new").value.length < 5) || (document.getElementById("admpass_new").value.length > 16))
		{
			$("#admpasslable").attr("title","长度应在5-16位之间！");
			$("#admpasslable").html("长度应在5-16位之间！"); 
			$("#admpasslable").show();
			flags = "1";
		}
		
		if ( !isAllEngAndNum(document.getElementById("admpass_new").value) )
		{   $("#admpasslable").attr("title","只允许字母，数字和下划线！");
			$("#admpasslable").html("只允许字母，数字和下划线！"); 
			$("#admpasslable").show();
			flags = "1";
		}
		
		if(newadmpass != newadmpass2nd){
		    $("#admpass2ndlable").attr("title","密码不一致，请重新输入！");
			$("#admpass2ndlable").show();
			flags = "1";
		}

		if(flags == "1")
		{
			flags = "0";
			return false;
		}
		
		$("#bgdiv").css("z-index","2002");
		$("#password_div").css("z-index","2003");
		$("#bgdiv").show();
		$("#password_div").show();
		
		$("#password_button").click(function(){
			document.getElementById("admpass").value = base64encode(utf16to8(document.getElementById("admpass_new").value));
			document.getElementById("admpass2nd").value = base64encode(utf16to8(document.getElementById("admpass2nd_new").value));
			document.Adm.submit();
		});
		
			$("#password_cancel").click(function(){
			$("#password_div").hide();
			$("#bgdiv").hide();
			$("#bgdiv").css("z-index","2000");
		});
	
}

function showUpdate()
{
	sw_verdesc = unescape(sw_verdesc.replace(/#x/g,'%u').replace(/;/g,''));
	$("#bgdiv").show();
	$("#bgdiv").css("z-index","1999");
	$("#alert_networkup_header").show();
	$("#alert_networkup_header").css("z-index","3001");
	$("#sw_alert1").html(currentVersion);
	$("#sw_alert2").html(newVersion);
	$("#sw_alert3").html(swPt);
	$("#sw_alert4").html(sw_verdesc);
}

function save_backup()
{   	
	//一键升级
	document.DoBackup.action="/cgi-bin/onekey_upgrade.cgi";
	document.DoBackup.submit();
	setTimeout("window.location.href = 'web_perbar.asp'",1000);
}

$("#upgrade_now").click(function(){     //一键升级
	document.DoBackup.action="/cgi-bin/onekey_upgrade.cgi";
	document.DoBackup.submit();
	setTimeout("window.location.href = 'web_perbar.asp'",1000);
});
		
 $(".pwd_eye_header1").click(function(){
		     if($(this).prev().attr("type") == "password"){
				 if($(this).parent().attr("data-ppp") == "yes")
				     var new_text = $("<input type='text' class=\"list-longtext\" maxLength='16' placeholder='运营商提供的上网密码'/>");
				 else{
					 if($(this).parent().attr("data-text") == "none")
						 var new_text = $("<input class=\"list-longtext\"  maxLength='16' type='text'/>");
					 else
					 {
						 if($(this).parent().attr("data-wl") == "no")
						 	var new_text = $("<input class=\"list-longtext\" type='text'  maxLength='16' placeholder='密码为空或不少于8位'/>");
						else	
						 var new_text = $("<input class=\"list-longtext\" type='text' maxLength='16' placeholder='密码不少于8位'/>");
					 }
				 }
				 if($(this).attr("data-color") == "white")
				     $(this).attr("src","images/icon_visible.png");
				 else
				     $(this).attr("src","images/icon_visible_gray.png");
				 $(new_text).attr("id",$(this).prev().attr("id"));
				 $(new_text).attr("name",$(this).prev().attr("name"));
				 $(new_text).val($(this).prev().val());
			     $(this).prev().replaceWith(new_text);
			 }else{
				 if($(this).parent().attr("data-ppp") == "yes")
				     var new_pwd = $("<input type='password' class=\"list-longtext\"  maxLength='16' placeholder='运营商提供的上网密码'/>");
				 else{
					 if($(this).parent().attr("data-text") == "none")
						 var new_pwd = $("<input class=\"list-longtext\"  maxLength='16' type='password'/>");
					 else
					 {
						 if($(this).parent().attr("data-wl") == "no")
						 	var new_pwd = $("<input class=\"list-longtext\"  maxLength='16' type='password' placeholder='密码为空或不少于8位'/>");
						 else
						    var new_pwd = $("<input class=\"list-longtext\"  maxLength='16' type='password' placeholder='密码不少于8位'/>");
					 }
				 }
				 if($(this).attr("data-color") == "white")
				     $(this).attr("src","images/icon_invisible.png");
				 else
				     $(this).attr("src","images/icon_invisible_gray.png");
				 $(new_pwd).attr("id",$(this).prev().attr("id"));
				 $(new_pwd).attr("name",$(this).prev().attr("name"));
				 $(new_pwd).val($(this).prev().val());
			     $(this).prev().replaceWith(new_pwd);
			 }
	});	
	
	$(".pwd_eye_header2").click(function(){
		     if($(this).prev().attr("type") == "password"){
				 if($(this).parent().attr("data-ppp") == "yes")
				     var new_text = $("<input type='text' class=\"list-longtext\"  maxLength='16' placeholder='运营商提供的上网密码'/>");
				 else{
					 if($(this).parent().attr("data-text") == "none")
						 var new_text = $("<input class=\"list-longtext\"  maxLength='16' type='text'/>");
					 else
					 {
						 if($(this).parent().attr("data-wl") == "no")
						 	var new_text = $("<input class=\"list-longtext\"   maxLength='16' type='text' placeholder='密码为空或不少于8位'/>");
						else	
						 var new_text = $("<input class=\"list-longtext\"  maxLength='16' type='text' placeholder='密码不少于8位'/>");
					 }
				 }
				 if($(this).attr("data-color") == "white")
				     $(this).attr("src","images/icon_visible.png");
				 else
				     $(this).attr("src","images/icon_visible_gray.png");
				 $(new_text).attr("id",$(this).prev().attr("id"));
				 $(new_text).attr("name",$(this).prev().attr("name"));
				 $(new_text).val($(this).prev().val());
			     $(this).prev().replaceWith(new_text);
			 }else{
				 if($(this).parent().attr("data-ppp") == "yes")
				     var new_pwd = $("<input type='password' class=\"list-longtext\"  maxLength='16' placeholder='运营商提供的上网密码'/>");
				 else{
					 if($(this).parent().attr("data-text") == "none")
						 var new_pwd = $("<input class=\"list-longtext\"  maxLength='16' type='password'/>");
					 else
					 {
						 if($(this).parent().attr("data-wl") == "no")
						 	var new_pwd = $("<input class=\"list-longtext\" type='password'  maxLength='16' placeholder='密码为空或不少于8位'/>");
						 else
						    var new_pwd = $("<input class=\"list-longtext\" type='password'  maxLength='16' placeholder='密码不少于8位'/>");
					 }
				 }
				 if($(this).attr("data-color") == "white")
				     $(this).attr("src","images/icon_invisible.png");
				 else
				     $(this).attr("src","images/icon_invisible_gray.png");
				 $(new_pwd).attr("id",$(this).prev().attr("id"));
				 $(new_pwd).attr("name",$(this).prev().attr("name"));
				 $(new_pwd).val($(this).prev().val());
			     $(this).prev().replaceWith(new_pwd);
			 }
	});	
	
	$(".pwd_eye_header3").click(function(){
		     if($(this).prev().attr("type") == "password"){
				 if($(this).parent().attr("data-ppp") == "yes")
				     var new_text = $("<input type='text' class=\"list-longtext\"  maxLength='16' placeholder='运营商提供的上网密码'/>");
				 else{
					 if($(this).parent().attr("data-text") == "none")
						 var new_text = $("<input class=\"list-longtext\"  maxLength='16' type='text'/>");
					 else
					 {
						 if($(this).parent().attr("data-wl") == "no")
						 	var new_text = $("<input class=\"list-longtext\" type='text'  maxLength='16' placeholder='密码为空或不少于8位'/>");
						else	
						 var new_text = $("<input class=\"list-longtext\" type='text'  maxLength='16' placeholder='密码不少于8位'/>");
					 }
				 }
				 if($(this).attr("data-color") == "white")
				     $(this).attr("src","images/icon_visible.png");
				 else
				     $(this).attr("src","images/icon_visible_gray.png");
				 $(new_text).attr("id",$(this).prev().attr("id"));
				 $(new_text).attr("name",$(this).prev().attr("name"));
				 $(new_text).val($(this).prev().val());
			     $(this).prev().replaceWith(new_text);
			 }else{
				 if($(this).parent().attr("data-ppp") == "yes")
				     var new_pwd = $("<input type='password' class=\"list-longtext\"  maxLength='16' placeholder='运营商提供的上网密码'/>");
				 else{
					 if($(this).parent().attr("data-text") == "none")
						 var new_pwd = $("<input class=\"list-longtext\"  maxLength='16' type='password'/>");
					 else
					 {
						 if($(this).parent().attr("data-wl") == "no")
						 	var new_pwd = $("<input class=\"list-longtext\" type='password'  maxLength='16' placeholder='密码为空或不少于8位'/>");
						 else
						    var new_pwd = $("<input class=\"list-longtext\" type='password'  maxLength='16' placeholder='密码不少于8位'/>");
					 }
				 }
				 if($(this).attr("data-color") == "white")
				     $(this).attr("src","images/icon_invisible.png");
				 else
				     $(this).attr("src","images/icon_invisible_gray.png");
				 $(new_pwd).attr("id",$(this).prev().attr("id"));
				 $(new_pwd).attr("name",$(this).prev().attr("name"));
				 $(new_pwd).val($(this).prev().val());
			     $(this).prev().replaceWith(new_pwd);
			 }
	});		
			
$("#upgrade_future").click(function(){
	$("#bgdiv").hide();
	$("#bgdiv").css("z-index","2000");
	$("#new_version").hide();
});

function up_exit()
{
	$("#bgdiv").hide();
	$("#bgdiv").css("z-index","2000");
	$("#alert_networkup_header").hide();
}

    $("#exit").click(function(){
		   $("#bgdiv").show();
		   $("#bgdiv").css("z-index","1999");
		   $("#logout_div").show();
	});

	/* use niceScroll roller */
	$(".left-side").niceScroll({styler:"fb",cursorcolor:"#F08300", cursorwidth: '3', cursorborderradius: '0px', spacebarenabled:false, cursorborder: '0',  zindex: '1000'});

    $(".left-side").mouseover(function(){
        $(".left-side").getNiceScroll().resize();
	});

    /* show left active */
    var url, path;
    $("#left-href li a").each(function() {
        url = $(this).attr('href');
		path = window.location.pathname;
        if (url == path.substr(path.lastIndexOf("\/")+1)) {
            jQuery(this).parent().addClass('active');
            return true;
        }
    });
	
    $(".menu-list > ul li a").each(function() {
        url = $(this).attr('href'); 
		path = window.location.pathname;
        if (url == path.substr(path.lastIndexOf("\/")+1)) {
            jQuery(this).parent().addClass('active');
            jQuery(this).parent().parent().parent().addClass('nav-active');
            return true;
        }
    });

    /* Toggle Left Menu */
    jQuery('.menu-list > a').click(function() {

      var parent = jQuery(this).parent();
      var sub = parent.find('> ul');
      
      if(!jQuery('body').hasClass('left-side-collapsed')) {
         if(sub.is(':visible')) {
            sub.slideUp(200, function(){
               parent.removeClass('nav-active');
               jQuery('.main-content').css({height: ''});
               /* K2_V2 should not change maincontent height by xichen 160513 */
               /* mainContentHeightAdjust(); */
               $(".left-side").getNiceScroll().resize();
            });
         } else {
            visibleSubMenuClose();
            parent.addClass('nav-active');
                sub.slideDown(200, function(){
                /* K2_V2 should not change maincontent height by xichen 160513 */
                /* mainContentHeightAdjust(); */
                $(".left-side").getNiceScroll().resize();
            });
         }
      }
      return false;
   });

   function visibleSubMenuClose() {
      jQuery('.menu-list').each(function() {
         var t = jQuery(this);
         if(t.hasClass('nav-active')) {
            t.find('> ul').slideUp(200, function(){
               t.removeClass('nav-active');
            });
         }
      });
   }

   /* class add mouse hover */
   jQuery('.custom-nav > li').hover(function(){
      jQuery(this).addClass('nav-hover');
   }, function(){
      jQuery(this).removeClass('nav-hover');
   });

