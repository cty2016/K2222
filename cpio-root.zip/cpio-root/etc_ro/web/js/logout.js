// JavaScript Document
function form_action(form,action_mode,set_id,wait_time){
	if(action_mode != "")
	    $("#action_mode").val(action_mode);
	$("#bgdiv").show();
	if(set_id != "")
	    $("#"+set_id).css("z-index","1999");
	$("#load_div").show();
	setTimeout("location.href = location.href",wait_time);
	form.submit();    
}
function alert_error(msg){
	if($(".set").length > 0){
		  $(".set").css("z-index","1999");
		}else{
		  $("#bgdiv").show();
		}
	$("#error_text").html(msg);
	$("#alert_error").show();
}

function alert_warn(msg){
	if($(".set").length > 0){
		  $(".set").css("z-index","1999");
		}else{
		  $("#bgdiv").show();
		}
	$("#warn_msg").html(msg);
	$("#alert_warn").show();
}


var error_div = $("<div id='bgdiv' class='bgdiv'></div><div id='load_div' class='load_div'><img id='load_img' class='load_img' src='images/load.GIF' /><br /><br /><div id='load_upgrade' class='load_text'>正在更改配置</div></div><div id='alert_error' class='error_div'><img src='images/icon_attention.png' /><span id='error_text'>输入有误!</span><div id='error_button' class='button_small'>确认</div></div><div id='logout_div' class='error_div'><span class='hint_span'>您确认要退出系统吗？</span><div id='logout_button' class='button_small'>确认</div><div id='logout_cancel' class='button_small_grey'>取消</div></div> <div id='alert_warn' class='error_div'><span class='hint_span' id='warn_msg'></span><div id='warn_button' class='button_small'>确认</div><div id='warn_cancel' class='button_small_grey'>取消</div></div> <div id='restart_div' class='error_div'><span class='hint_span'>点击确认系统重启!</span><div id='restart_button' class='button_small'>确认</div><div id='restart_cancel' class='button_small_grey'>取消</div></div><div id='delete_div' class='error_div'><span class='hint_span'>确认删除？</span><div id='delete_button' class='button_small'>确认</div><div id='delete_cancel' class='button_small_grey'>取消</div></div><div id='password_div' class='error_div'><span class='hint_span'>修改完成后需要重新登录！</span><div id='password_button' class='button_small'>确认</div><div id='password_cancel' class='button_small_grey'>取消</div></div><div id='sysreboot_div' class='error_div'><span class='hint_span'>网络访问将暂时中断，升级成功后，路由器将重启！确认升级请点击“确认”，暂不升级请点击“取消”！</span><div id='sysreboot_button' class='button_small'>确认</div><div id='sysreboot_cancel' class='button_small_grey'>取消</div></div><div id='restore_div' class='error_div'><span class='hint_span'>警告！恢复出厂设置后将清空当前所有设置。继续请按“确认”，返回请按“取消”！</span><div id='restore_button' class='button_small'>确认</div><div id='restore_cancel' class='button_small_grey'>取消</div></div><div id='alert_confirm' class='error_div'><img src='images/icon_attention.png' /><span id='confirm_text'></span><div id='confirm_button' class='button_small'>确认</div></div>");
$(".main-shadow").after(error_div);
$(".home-shadow").after(error_div);
$(function(){
	$("#source").click(function(){		   
		   $("#bgdiv").show();
		   $("#restart_div").show();
	});
	
    $("#restart_button").click(function(){
		 // document.reboot_form.submit(); 
		 $.post("/goform/gra_doReboot",
		           {reboot:1},
				 function(data,textStatus){
				    location.href = "webback.asp?t=2";
				 }
		 ); 
	});
	
	$("#restart_cancel").click(function(){
		   $("#restart_div").hide();
		   $("#bgdiv").hide();
	});
	
	$("#exit").click(function(){
		   $("#bgdiv").show();
		   $("#logout_div").show();
	});
	
	$("#logout_button").click(function(){
		   //document.logout_form.submit();
		   $.post("/goform/gra_setLogout",
		           {logApply:1},
				   function(data,textStatus){
//						alert(data);
						if(data == "PC")
							location.href = "login.asp";
						else if(data == "PHONE")
							location.href = "sbxh.asp";
						else
							location.href = "login.asp";
				   }
		   );  
	});
	
	$("#logout_cancel").click(function(){
		   $("#logout_div").hide();
		   $("#bgdiv").hide();
	});
	
	$("#warn_cancel").click(function(){
		   $("#alert_warn").hide();
		   $("#bgdiv").hide();
	});
	
	$("#small_code").hover(function(){
	       $("#code").show();
	},function(){
	       $("#code").hide();
	});
	
	$(".history_back").click(function(){
		//window.history.go(-1);
		location.href = "index.asp";
	});
	
	$("#error_button").click(function(){
		   if($(".set").length > 0){
			  $(".set").css("z-index","2001");
		   }else{
		      $("#bgdiv").hide();
		   }
		   $("#alert_error").hide();		  
	});
	
	$("#confirm_button").click(function(){
		    $("#bgdiv").hide();
			$("#alert_confirm").hide();
		    
	});
	
	$(".pwd_eye").click(function(){
		     if($(this).prev().attr("type") == "password"){
				 if($(this).parent().attr("data-ppp") == "yes")
				     var new_text = $("<input type='text' class=\"list-longtext\" placeholder='运营商提供的上网密码'/>");
				 else{
					 if($(this).parent().attr("data-text") == "none")
						 var new_text = $("<input class=\"list-longtext\" type='text'/>");
					 else
					 {
						 if($(this).parent().attr("data-wl") == "no")
						 	var new_text = $("<input class=\"list-longtext\" type='text' placeholder='密码为空或不少于8位'/>");
						else	
						 var new_text = $("<input class=\"list-longtext\" type='text' placeholder='密码不少于8位'/>");
					 }
				 }
				 if($(this).attr("data-color") == "white")
				     $(this).attr("src","images/icon_visible.png");
				 else
				     $(this).attr("src","images/icon_visible_gray.png");
				 $(new_text).attr("id",$(this).prev().attr("id"));
				 $(new_text).attr("name",$(this).prev().attr("name"));
				 $(new_text).val($(this).prev().val());
			     $(this).prev().replaceWith(new_text);
			 }else{
				 if($(this).parent().attr("data-ppp") == "yes")
				     var new_pwd = $("<input type='password' class=\"list-longtext\" placeholder='运营商提供的上网密码'/>");
				 else{
					 if($(this).parent().attr("data-text") == "none")
						 var new_pwd = $("<input class=\"list-longtext\" type='password'/>");
					 else
					 {
						 if($(this).parent().attr("data-wl") == "no")
						 	var new_pwd = $("<input class=\"list-longtext\" type='password' placeholder='密码为空或不少于8位'/>");
						 else
						    var new_pwd = $("<input class=\"list-longtext\" type='password' placeholder='密码不少于8位'/>");
					 }
				 }
				 if($(this).attr("data-color") == "white")
				     $(this).attr("src","images/icon_invisible.png");
				 else
				     $(this).attr("src","images/icon_invisible_gray.png");
				 $(new_pwd).attr("id",$(this).prev().attr("id"));
				 $(new_pwd).attr("name",$(this).prev().attr("name"));
				 $(new_pwd).val($(this).prev().val());
			     $(this).prev().replaceWith(new_pwd);
			 }
	});
	
})