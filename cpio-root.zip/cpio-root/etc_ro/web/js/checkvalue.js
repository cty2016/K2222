// JavaScript Document
function checkvalue(obj){
	var formid = obj.getAttribute("id");
	var inputlist = $("#"+formid+" input");
	var i = 0;
	var data_type;
	for (i = 0; i < inputlist.length; i++){
	     if(inputlist[i].dataset)
		        data_type = inputlist[i].dataset.type;
		 else
		        data_type = inputlist[i].getAttribute("data-type");
	     if(data_type=="ip"){
			 	throwBlank(inputlist[i]);
				if(inputlist[i].value == "")
				{
					$("#error_text").html("IP地址不能为空！");
					$("#bgdiv").show();	
					$("#alert_error").show();		
					return false;
				}	
				else if(!checkIp(inputlist[i]))
				{
					$("#error_text").html("无效的IP地址，请重新输入！");
					$("#bgdiv").show();	
					$("#alert_error").show();	
					inputlist[i].focus();
					return false;
				}
		 }
	}
	return true;
}

$(function(){
	$("#error_button").click(function(){
		$("#alert_error").hide();
		$("#bgdiv").hide();	
	});
    $("#savelan").click(function(){
		$("#savelan1").click();
	});

})