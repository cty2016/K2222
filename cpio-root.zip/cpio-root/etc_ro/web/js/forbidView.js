function isValidChar(str)
{
	for (var i=0; i<str.length; i++){
	    if( (str.charAt(i) >= '0' && str.charAt(i) <= '9') || (str.charAt(i) == '.') || (str.charAt(i) == '/') ||
      (str.charAt(i) >= 'a' && str.charAt(i) <= 'z') || (str.charAt(i) >= 'A' && str.charAt(i) <= 'Z') ||
      (str.charAt(i) == '-') || (str.charAt(i) == '_') )
			continue;
		return 0;
	}
	return 1;
}

function checkspecialchar(obj)
{
	var s = obj.value;
	for(var i = 0; i < s.length; i++) 
	{
	    if(s.charAt(i).match(/[\u0391-\uFFE5]/) || s.charAt(i).match(/[\u00B7]/)
			|| s.charAt(i).match(/[\u0022]/) || s.charAt(i).match(/[\u0026]/)
			|| s.charAt(i).match(/[\u003E]/) || s.charAt(i).match(/[\u003C]/)
			|| s.charAt(i).match(/[\u005C]/) || s.charAt(i).match(/[\u0027]/))
		{ 
			return false; 
		}
	}
	return true;
}

function validateKey(str)
{
	var str_item = str.split('.');
	for(var i=0; i<str_item.length; i++){
	   for (var j=0; j<str_item[i].length; j++) {
	    if (str_item[i].charAt(j) >= '0' && str_item[i].charAt(j) <= '9')
				continue;
		return 0;
	  }
	}
	return 1;
}

function getDigit(str, num)
{
  i=1;
  if ( num != 1 ) {
  	while (i!=num && str.length!=0) {
		if ( str.charAt(0) == '.' ) {
			i++;
		}
		str = str.substring(1);
  	}
  	if ( i!=num )
  		return -1;
  }
  for (i=0; i<str.length; i++) {
  	if ( str.charAt(i) == '.' ) {
		str = str.substring(0, i);
		break;
	}
  }
  if ( str.length == 0)
  	return -1;
  var d = parseInt(str, 10);
  return d;
}

function checkDigitRange(str, num, min, max)
{
  var d = getDigit(str,num);
  if ( d > max || d < min )
      	return false;
  return true;
}

function checkDomain(dm)
{
	var postfix = /^([\w-]+\.)+((aero)|(asia)|(biz)|(cat)|(com)|(coop)|(edu)|(gov)|(info)|(jobs)|(mil)|(mobi)|(museum)|(name)|(net)|(org)|(pro)|(tel)|(travel)|(xxx)|(ac)|(ad)|(ae)|(af)|(ag)|(ai)|(al)|(am)|(an)|(ao)|(aq)|(ar)|(as)|(at)|(au)|(aw)|(ax)|(az)|(ba)|(bb)|(bd)|(be)|(bf)|(bg)|(bh)|(bi)|(bj)|(bm)|(bn)|(bo)|(br)|(bs)|(bt)|(bv)|(bw)|(by)|(bz)|(ca)|(cc)|(cd)|(cf)|(cg)|(ch)|(ci)|(ck)|(cl)|(cm)|(cn)|(co)|(cr)|(cu)|(cv)|(cx)|(cy)|(cz)|(de)|(dj)|(dk)|(dm)|(dz)|(ec)|(ee)|(eg)|(er)|(es)|(et)|(eu)|(fi)|(fj)|(fk)|(fm)|(fo)|(fr)|(ga)|(gb)|(gd)|(ge)|(gf)|(gg)|(gh)|(gi)|(gl)|(gm)|(gn)|(gp)|(gq)|(gr)|(gs)|(gt)|(gu)|(gw)|(gy)|(hk)|(hm)|(hn)|(hr)|(ht)|(hu))$/;
	var postfix1 =/^([\w-]+\.)+((id)|(ie)|(il)|(im)|(in)|(io)|(iq)|(ir)|(is)|(it)(je)|(jm)|(jo)|(jp)|(ke)|(kg)|(kh)|(ki)|(km)|(kn)|(kp)|(kr)|(kw)|(ky)|(kz)|(la)|(lb)|(lc)|(li)|(lk)|(lr)|(ls)|(lt)|(lu)|(lv)|(ly)|(ma)|(mc)|(md)|(me)|(mg)|(mh)|(mk)|(ml)|(mm)|(mn)|(mo)|(mp)|(mq)|(mr)|(ms)|(mt)|(mu)|(mv)|(mw)|(mx)|(my)|(mz)|(na)|(nc)|(ne)|(nf)|(ng)|(ni)|(nl)|(no)|(np)|(nr)|(nu)|(nz)|(om)|(pa)|(pe)|(pf)|(pg)|(ph)|(pk)|(pl)|(pm)|(pn)|(pr)|(ps)|(pt)|(pw)|(py)|(qa)|(re)|(ro)|(rs)|(ru)|(rw)|(sa)|(sb)|(sc)|(sd)|(se)|(sg)|(sh)|(si)|(sj)|(sk)|(sl)|(sm)|(sn)|(so)|(sr)|(st)|(su)|(sv)|(sy)|(sz)|(tc)|(td)|(tf)|(tg)|(th)|(tj)|(tk)|(tl))$/;	
	var postfix2 =/^([\w-]+\.)+((tm)|(tn)|(to)|(tp)|(tr)|(tt)|(tv)|(tw)|(tz)|(ua)|(ug)|(uk)|(us)|(uy)|(uz)|(va)|(vc)|(ve)|(vg)|(vi)|(vn)|(vu)|(wf)|(ws)|(ye)|(yt)|(za)|(zm)|(zw))$/;
	if(!postfix.test(dm) && !postfix1.test(dm) && !postfix2.test(dm))
	    {
	        return false;
	    }
	return true;
}

function checkAddrdmz(field)
{
	if(field.value.split(".").length > 4)
	{
		return false;
	}
	if (field.value == "") {
		return false;
	}
	if ( validateKey(field.value) == 0) {
		return false;
	}
    if((getDigit(field.value,1) < 1) || ((getDigit(field.value,1) < 240) && (getDigit(field.value,1) > 223)) || (getDigit(field.value,1) > 254))
    {
        return false;
    }
	if ( getDigit(field.value,1) ==127) {
		return false;
	}
	if ( !checkDigitRange(field.value,2,0,255) ) {
		return false;
	}
	if ( !checkDigitRange(field.value,3,0,255) ) {
		return false;
	}
	if ( !checkDigitRange(field.value,4,1,254) ) {
		return false;
	}
	return true;
}

function get_ip(str_ip)
{
	var myIP=new Array();

	myIP[0] = myIP[1] = myIP[2] = myIP[3] = myIP[4] = "";
	if (str_ip != "")
	{
		var tmp=str_ip.split(".");
		for (var i=1;i <= tmp.length;i++) myIP[i]=tmp[i-1];
		myIP[0]=str_ip;
	}
	else
	{
		for (var i=0; i <= 4;i++) myIP[i]="";
	}
	return myIP;
}

function get_network_id(ip, mask)
{
	var id = new Array();
	var ipaddr = get_ip(ip);
	var subnet = get_ip(mask);

	id[1] = ipaddr[1] & subnet[1];
	id[2] = ipaddr[2] & subnet[2];
	id[3] = ipaddr[3] & subnet[3];
	id[4] = ipaddr[4] & subnet[4];
	id[0] = id[1]+"."+id[2]+"."+id[3]+"."+id[4];
	return id;
}

function verifip(ip)
{
	if (ip.value == "")
		return "";
	
	var arr = ip.value.split(".");
    var ret = "";

	for (var i = 0; i < arr.length; i++)
	{
		if (parseInt(arr[i], 10) != "0")
		{
			arr[i] = arr[i].replace(/\b(0+)/gi, "");
		}
		else
		{
		 	arr[i] = parseInt(arr[i], 10);
		}

        if (i == arr.length - 1)
        {
            ret = ret + arr[i];
        }
        else
        {
            ret = ret + arr[i] + ".";
        }
	}
	 return ret;
}

function isAllEngAndNum(str)
{
	for (var i=0; i<str.length; i++){
		if((str.charAt(i) >= 'a' && str.charAt(i) <= 'z') || (str.charAt(i) >= 'A' && str.charAt(i) <= 'Z') ||
			(str.charAt(i) >= '0' && str.charAt(i) <= '9')||str.charAt(i)=='_' )
			continue;
		return false;
	}
	return true;
}

function checkAllNumEn(str)
{
    for (var i=0; i<str.length; i++){
        if(str.charAt(i) >= '0' && str.charAt(i) <= '9')
        {
            continue;
        }
        return false;
    }
    return true;
}

function checkWebIp(fobj) 
{ 		
	var tmp = fobj.value;
	var ip= /^([0-9]|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(([0-9]|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.){2}([0-9]|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])$/;
	if(ip.exec(tmp)==null)
		return 0;
    var ipaddr = tmp.split(".");
	if(ipaddr.length != 4 ) 
		return 0; 	
	for(i = 0; i < 4; i++) {
		if(ipaddr[i] =="")
		return 0;   
	}	    
    if(parseInt(ipaddr[0]) == 127 || (parseInt(ipaddr[0])>223 && parseInt(ipaddr[0])<255))
        return 0;
	if(parseInt(ipaddr[0]) ==0 && parseInt(ipaddr[1]) ==0 && parseInt(ipaddr[2]) ==0 && parseInt(ipaddr[3]) ==0){			
		return 2;
	}
	if(parseInt(ipaddr[0]) ==255 && parseInt(ipaddr[1]) ==255 && parseInt(ipaddr[2]) ==255 && parseInt(ipaddr[3]) ==255){			
		return 3;
	}	
    if(parseInt(ipaddr[0]) >0 && parseInt(ipaddr[0]) <255 && parseInt(ipaddr[1])>=0 && parseInt(ipaddr[1])<=255 && parseInt(ipaddr[2])>=0 && parseInt(ipaddr[2])<=255 && parseInt(ipaddr[3])>0 && parseInt(ipaddr[3])<255)  
        return 1;  
    else
    	return 0; 	
}

function checkServerForm(str)
{
	for(var i=0; i<str.length; i++)
	{
		if((str.charAt(i) >= '0' && str.charAt(i) <= '9') || (str.charAt(i) == '.') || (str.charAt(i) == '-') ||
			(str.charAt(i) == '_') || (str.charAt(i) >= 'a' && str.charAt(i) <= 'z') || (str.charAt(i) >= 'A' && str.charAt(i) <= 'Z'))
		{
			if( i==0 || i==(str.length-1) ){
				if( (str.charAt(i) == '.') || (str.charAt(i) == '-') || (str.charAt(i) == '_'))
					return false;
			}

			else
			{
				if((str.charAt(i) == '.' && str.charAt(i+1) == '.'))
				{
					return false;
				}
			}
			continue;
		}
		return false;
	}
	return true;
}

function checkIpAddr1(field)
{
     if(field.value.split(".").length > 4)
			return false;
     if (field.value == "") 
			return false;
     if ( validateKey(field.value) == 0) 
			return false;
     if ( !checkDigitRange(field.value,1,1,223) ) 
			return false;
     if ( getDigit(field.value,1) ==127) 
			return false;
     if ( !checkDigitRange(field.value,2,0,255) ) 
			return false;
     if ( !checkDigitRange(field.value,3,0,255) ) 
			return false;
     if ( !checkDigitRange(field.value,4,0,254) ) 
			return false;
     return true;
}

function atoi(str, num)
{
	var i = 1;
	if (num != 1) {
		while (i != num && str.length != 0) {
			if (str.charAt(0) == '.') {
				i++;
			}
			str = str.substring(1);
		}
		if (i != num)
			return -1;
	}

	for (i=0; i<str.length; i++) {
		if (str.charAt(i) == '.') {
			str = str.substring(0, i);
			break;
		}
	}
	if (str.length == 0)
		return -1;
	return parseInt(str, 10);
}

function stoi(str)
{
	var num = parseInt(str,10);
	if(isNaN(num))
	{
		return("");
	}
	else
	{
		return num;
	}
}

var str_err;
var strasc_err;
function checkHex2(str)
{
	var len = str.length;
	for (var i=0; i<str.length; i++) {
		if ((str.charAt(i) >= '0' && str.charAt(i) <= '9') ||
			(str.charAt(i) >= 'a' && str.charAt(i) <= 'f') ||
			(str.charAt(i) >= 'A' && str.charAt(i) <= 'F') ){
				continue;
		}else
		{
			str_err = str[i];
	        return false;
		}
	}
    return true;
}


function checkascii2(str){	
	for(var i=0; i<str.length; i++){
		if(str.charCodeAt(i)>=0 && str.charCodeAt(i)<=127)
			continue;
		else
		{
			strasc_err = str[i];
			return false;
		}
	 }
	return true;
}

function checkspecialchar2(obj)
{
	var s = obj.value;
	for(var i = 0; i < s.length; i++) 
	{
	    if(s.charAt(i).match(/[\u00B7]/)
				  || s.charAt(i).match(/[\u0022]/) || s.charAt(i).match(/[\u0026]/)
				  || s.charAt(i).match(/[\u003E]/) || s.charAt(i).match(/[\u003C]/)//<>
				  || s.charAt(i).match(/[\u005C]/) || s.charAt(i).match(/[\u0027]/)
				  || s.charAt(i).match(/[\u0028]/) || s.charAt(i).match(/[\u0029]/)//()
				  || s.charAt(i).match(/[\u007E]/)//~
				  || s.charAt(i).match(/[\u007B]/) || s.charAt(i).match(/[\u007D]/)//{}
				  || s.charAt(i).match(/[\u0025]/)
				  || s.charAt(i).match(/[\u003A]/) || s.charAt(i).match(/[\u003B]/)//{}
				  || s.charAt(i).match(/[\u002C]/))
		{
			return false; 
		}
	}
	return true;
}

function getStrByteLen(obj)
{ 
     var len = 0; 
	 str = obj.value;
     for (var i = 0; i < str.length; i++) 
	 { 
         if (str.charAt(i).match(/[\u0391-\uFFE5]/))
            len += 3; 
         else
             len += 1; 
     } 
     if (len > 32)
	 {
		return false;
     } 
     return true;
}