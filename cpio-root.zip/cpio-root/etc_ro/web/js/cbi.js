/*
	LuCI - Lua Configuration Interface

	Copyright 2008 Steven Barth <steven@midlink.org>
	Copyright 2008-2012 Jo-Philipp Wich <xm@subsignal.org>

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0
*/

var cbi_d = [];
var cbi_t = [];
var cbi_c = [];

var error_msg = [
       ["0","无效！"],
       ["1","不能为空！"],
	   ["2","过长！"],
	   ["3","范围应在"],
	   ["4","长度应在"],
	   ["5","错误！"],
	   ["6","与"],
	   ["7","之间！"],
	   ["8","位之间！"],
	   ["9","不能含有空格！"],
	   ["10","应为整数！"],
	   ["11","不允许输入\<\>(){}\&\'\"\\%\,\:\;~和中文字符"],
	   ["12","不允许输入\<\>(){}\&\'\"\\%\,\:\;~"],
	   ["13","应输入8-63位ASCII码字符或8-64位十六进制字符"],
	   ["14","不允许输入\<\>(){}\&\'\"\\%\,\:\;"],
	   ["15","不允许输入\<\>(){}\&\'\"\\%\,\:\;和中文字符"],
	   ["16","长度不能超过"],
	   ["17","位！"],
	   ["18","应为正整数！"],
	   ["19","不为空时不可少于8位！"],
	   ["20","不可少于8位！"],
	];
	
var cbi_validators = {

	'integer': function()
	{
		if(this.match(/^-?[0-9]+$/) != null)
		    return true;
		else
		    return error_msg[10][1];
	},

	'uinteger': function()
	{
		//return (cbi_validators.integer.apply(this) && (this >= 0));
		if(typeof(cbi_validators.integer.apply(this))==="boolean" && (this >= 0))
		    return true;
		else 
		    return error_msg[18][1];
	},

	'float': function()
	{
		return !isNaN(parseFloat(this));
	},

	'ufloat': function()
	{
		return (cbi_validators['float'].apply(this) && (this >= 0));
	},

	'ipaddr': function()
	{
		/*return cbi_validators.ip4addr.apply(this) ||
			cbi_validators.ip6addr.apply(this);*/
		if(cbi_validators.ip4addr.apply(this) || cbi_validators.ip6addr.apply(this))
		     return true;
		else
		     return error_msg[0][1];
	},

	'ip4addr': function()
	{
		if (this.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})(\/(\S+))?$/))
		{
			return (RegExp.$1 >= 0) && (RegExp.$1 <= 255) &&
			       (RegExp.$2 >= 0) && (RegExp.$2 <= 255) &&
			       (RegExp.$3 >= 0) && (RegExp.$3 <= 255) &&
			       (RegExp.$4 >= 0) && (RegExp.$4 <= 255) &&
			       ((RegExp.$6.indexOf('.') < 0)
			          ? ((RegExp.$6 >= 0) && (RegExp.$6 <= 32))
			          : (cbi_validators.ip4addr.apply(RegExp.$6)))
			;
		}

		return false;
	},

	'ip6addr': function()
	{
		if( this.match(/^([a-fA-F0-9:.]+)(\/(\d+))?$/) )
		{
			if( !RegExp.$2 || ((RegExp.$3 >= 0) && (RegExp.$3 <= 128)) )
			{
				var addr = RegExp.$1;

				if( addr == '::' )
				{
					return true;
				}

				if( addr.indexOf('.') > 0 )
				{
					var off = addr.lastIndexOf(':');

					if( !(off && cbi_validators.ip4addr.apply(addr.substr(off+1))) )
						return false;

					addr = addr.substr(0, off) + ':0:0';
				}

				if( addr.indexOf('::') >= 0 )
				{
					var colons = 0;
					var fill = '0';

					for( var i = 1; i < (addr.length-1); i++ )
						if( addr.charAt(i) == ':' )
							colons++;

					if( colons > 7 )
						return false;

					for( var i = 0; i < (7 - colons); i++ )
						fill += ':0';

					if (addr.match(/^(.*?)::(.*?)$/))
						addr = (RegExp.$1 ? RegExp.$1 + ':' : '') + fill +
						       (RegExp.$2 ? ':' + RegExp.$2 : '');
				}

				return (addr.match(/^(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}$/) != null);
			}
		}

		return false;
	},

	'port': function()
	{
		return cbi_validators.integer.apply(this) &&
			(this >= 0) && (this <= 65535);
	},

	'portrange': function()
	{
		if (this.match(/^(\d+)-(\d+)$/))
		{
			var p1 = RegExp.$1;
			var p2 = RegExp.$2;

			return cbi_validators.port.apply(p1) &&
			       cbi_validators.port.apply(p2) &&
			       (parseInt(p1) <= parseInt(p2))
			;
		}
		else
		{
			return cbi_validators.port.apply(this);
		}
	},

	'macaddr': function()
	{
		return (this.match(/^([a-fA-F0-9]{2}:){5}[a-fA-F0-9]{2}$/) != null);
	},

	'host': function()
	{
		/*return cbi_validators.hostname.apply(this) ||
			cbi_validators.ipaddr.apply(this);*/
		if (typeof(cbi_validators.hostname.apply(this))==="string" && typeof(cbi_validators.ipaddr.apply(this))==="string")
		     return error_msg[0][1];
		else
		     return true;
	},

	'hostname': function()
	{
		if (this.length <= 253)
			if(this.match(/^[a-zA-Z0-9]+$/) != null ||
			        (this.match(/^[a-zA-Z0-9_][a-zA-Z0-9_\-.]*[a-zA-Z0-9]$/) &&
			         this.match(/[^0-9.]/)))
			    return true;
			else
			    return error_msg[0][1];

		return false;
	},

	'network': function()
	{
		return cbi_validators.uciname.apply(this) ||
			cbi_validators.host.apply(this);
	},

	'wpakey': function()
	{
		var v = this;

		if( v.length == 64 ){
			//return (v.match(/^[a-fA-F0-9]{64}$/) != null);
			if(v.match(/^[a-fA-F0-9]{64}$/) != null)
			    return true;
			else
			    return error_msg[13][1];
		}
		else{
			//return (v.length >= 8) && (v.length <= 63);
			if((v.length >= 8) && (v.length <= 63))
			    return true;
			else
			    return error_msg[13][1];
		}
	},

	'wepkey': function()
	{
		var v = this;

		if ( v.substr(0,2) == 's:' )
			v = v.substr(2);

		if( (v.length == 10) || (v.length == 26) )
			return (v.match(/^[a-fA-F0-9]{10,26}$/) != null);
		else
			return (v.length == 5) || (v.length == 13);
	},

	'uciname': function()
	{
		return (this.match(/^[a-zA-Z0-9_]+$/) != null);
	},

	'range': function(min, max)
	{
		var val = parseFloat(this);
		if (!isNaN(min) && !isNaN(max) && !isNaN(val))
			if((val >= min) && (val <= max))
			   return true;
			else 
			   return error_msg[3][1]+min+error_msg[6][1]+max+error_msg[7][1];

		return error_msg[3][1]+min+error_msg[6][1]+max+error_msg[7][1];
	},

	'min': function(min)
	{
		var val = parseFloat(this);
		if (!isNaN(min) && !isNaN(val))
			return (val >= min);

		return false;
	},

	'max': function(max)
	{
		var val = parseFloat(this);
		if (!isNaN(max) && !isNaN(val))
			return (val <= max);

		return false;
	},

	'rangelength': function(min, max)
	{
		var val = '' + this;
		if (!isNaN(min) && !isNaN(max))
			if((val.length >= min) && (val.length <= max))
			    return true;
			else
			    return error_msg[4][1]+min+error_msg[6][1]+max+error_msg[8][1];

		return false;
	},

	'minlength': function(min)
	{
		var val = '' + this;
		if (!isNaN(min))
			return (val.length >= min);

		return false;
	},

	'maxlength': function(max)
	{
		var val = '' + this;
		if (!isNaN(max))
			//return (val.length <= max);
			if(val.length <= max)
			    return true;
			else
			    return error_msg[16][1] +max+ error_msg[17][1];

		return false;
	},

	'or': function()
	{
		var val_check = "";
		for (var i = 0; i < arguments.length; i += 2)
		{
			if (typeof arguments[i] != 'function')
			{
				if (arguments[i] == this)
					return true;
				i--;
			}
			else {
				val_check = arguments[i].apply(this, arguments[i+1]);
				if (val_check && typeof(val_check) === "boolean")
				{
					return true;
				}
			}
		}
		return val_check;
	},

	'and': function()
	{
		var val_check = "";
		for (var i = 0; i < arguments.length; i += 2)
		{
			if (typeof arguments[i] != 'function')
			{
				if (arguments[i] != this)
					return false;
				i--;
			}
			else{ 
				if(arguments[i+1] != null)
			        val_check = arguments[i].apply(this, arguments[i+1]);
				else
				     val_check = arguments[i].apply(this);
				if (typeof(val_check) === "string")
				{
					return val_check;
				}
			}
		}
		return true;
	},

	'neg': function()
	{
		return cbi_validators.or.apply(
			this.replace(/^[ \t]*![ \t]*/, ''), arguments);
	},

	'list': function(subvalidator, subargs)
	{
		if (typeof subvalidator != 'function')
			return false;

		var tokens = this.match(/[^ \t]+/g);
		for (var i = 0; i < tokens.length; i++)
			if (!subvalidator.apply(tokens[i], subargs))
				return false;

		return true;
	},
	'phonedigit': function()
	{
		return (this.match(/^[0-9\*#!\.]+$/) != null);
	},
	'filename': function()
	{
		return (this.length != 0);
	},
		
	'sperangelength':function(min,max)
	{
		 var val = '' + this;
		 var i = 0;
		 var textlength = 0;
		 if (!isNaN(min) && !isNaN(max)){
			 for(i = 0;i < val.length;i ++){
				 if(val.charAt(i).match(/[\u0391-\uFFE5]/))
					  textlength = textlength + 3;
					else
					  textlength = textlength + 1;		  	      
			 }			  
			 if((textlength >= min) && (textlength <= max))
			    return true;
			 else
			    return error_msg[2][1];
			 
		 }
		 return false;

	},
	
	'sperangelength_short':function()
	{
		 var val = '' + this;
		 var i = 0;
		 var textlength = val.length;
		 if((textlength >= 1) && (textlength <=7))
		 {
			return error_msg[19][1];
			return false;
		 }
		 else
			return true;
	},
	
	'sperangelength_long':function()
	{
		 var val = '' + this;
		 var i = 0;
		 var textlength = val.length;
		 if((textlength >= 1) && (textlength <=7))
		 {
			return error_msg[20][1];
			return false;
		 }
		 else
			return true;
	},
	
	'ipv4lan':function()
	{
	      var tmp = '' + this;
		  var ip= /^([1-9]|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(([0-9]|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.){2}([1-9]|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])$/;
		  if(ip.exec(tmp)==null)
			  return error_msg[0][1];
		  var ipaddr = tmp.split(".");
		  if(ipaddr.length != 4 ) 
			  return error_msg[0][1]; 	
		  for(i = 0; i < 4; i++) {
			  if(ipaddr[i] =="")
			  return error_msg[0][1];   
		  }	    
		  if(parseInt(ipaddr[0]) == 127 || parseInt(ipaddr[0])>223)
			  return error_msg[0][1];    
		  if(parseInt(ipaddr[0]) >0 && parseInt(ipaddr[0]) <255 && parseInt(ipaddr[1])>=0 && parseInt(ipaddr[1])<=255 && parseInt(ipaddr[2])>=0 && parseInt(ipaddr[2])<=255 && parseInt(ipaddr[3])>0 && parseInt(ipaddr[3])<255) 
			  return true;  
		  else
			  return error_msg[0][1]; 
	 },
	 
	 'ipv4':function()
	 {
		  var tmp = '' + this;
		  var ip= /^([1-9]|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(([0-9]|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.){2}([1-9]|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])$/;
		  if(ip.exec(tmp)==null)
			  return error_msg[0][1];
		  var ipaddr = tmp.split(".");
		  if(ipaddr.length != 4 ) 
			  return error_msg[0][1]; 	
		  for(i = 0; i < 4; i++) {
			  if(ipaddr[i] =="")
			  return error_msg[0][1];   
		  }	    
		  if(parseInt(ipaddr[0]) == 127 || ( parseInt(ipaddr[0])>223 && parseInt(ipaddr[0])<240))/*different*/
			  return error_msg[0][1];    
		  if(parseInt(ipaddr[0]) >0 && parseInt(ipaddr[0]) <255 && parseInt(ipaddr[1])>=0 && parseInt(ipaddr[1])<=255 && parseInt(ipaddr[2])>=0 && parseInt(ipaddr[2])<=255 && parseInt(ipaddr[3])>0 && parseInt(ipaddr[3])<255) 
			  return true;  
		  else
			  return error_msg[0][1];
	 },
	 
	 'changeip':function()
	 {
	      return (this+256).toString(2).substring(1); 
	 },
	 
	 'ipv4mask':function()
	 {
	      var MaskStr = '' + this;
		  var IPPattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
		  if(!IPPattern.test(MaskStr))
		      return error_msg[0][1]; 
		  
		  var IPArray = MaskStr.split("."); 
		  var ip1 = parseInt(IPArray[0]); 
		  var ip2 = parseInt(IPArray[1]); 
		  var ip3 = parseInt(IPArray[2]); 
		  var ip4 = parseInt(IPArray[3]); 
		  if ( ip1<=0 || ip1>255 
			 || ip2<0 || ip2>255 
			 || ip3<0 || ip3>255 
			 || ip4<0 || ip4>255 ) 
		  { 
			 return error_msg[0][1]; 
		  } 	
		  var ip_binary = cbi_validators.changeip.apply(ip1) + 
		                  cbi_validators.changeip.apply(ip2) + 
						  cbi_validators.changeip.apply(ip3) + 
						  cbi_validators.changeip.apply(ip4); 	
		  if(-1 != ip_binary.indexOf("01"))  
		     return error_msg[0][1]; 
		  return true; 
	 },
	 
	 'blank':function()
	 {
		  var blankcheck = /[\s]+/g;
		  var val = '' + this;
		  if(blankcheck.test(val))
		      return error_msg[9][1];
		  else
		      return true;

	 },
	 
	 'checkspecialchar_cn':function()
	 {
		 var s = "" + this;
		  for(var i = 0; i < s.length; i++) 
		  {
			  if(s.charAt(i).match(/[\u0391-\uFFE5]/) || s.charAt(i).match(/[\u00B7]/)
				  || s.charAt(i).match(/[\u0022]/) || s.charAt(i).match(/[\u0026]/)
				  || s.charAt(i).match(/[\u003E]/) || s.charAt(i).match(/[\u003C]/)
				  || s.charAt(i).match(/[\u005C]/) || s.charAt(i).match(/[\u0027]/)
				  || s.charAt(i).match(/[\u0028]/) || s.charAt(i).match(/[\u0029]/)//()
				  || s.charAt(i).match(/[\u007E]/)//~
				  || s.charAt(i).match(/[\u007B]/) || s.charAt(i).match(/[\u007D]/)//{}
				  || s.charAt(i).match(/[\u0025]/)
				  || s.charAt(i).match(/[\u003A]/) || s.charAt(i).match(/[\u003B]/)//{}
				  || s.charAt(i).match(/[\u002C]/))//%)			  
			  { 
				  return error_msg[11][1]; 
			  }
		  }
		  return true;
	 
	 },
	 
	 'checkspecialchar':function()
	 {
	      var s = "" + this;
		  for(var i = 0; i < s.length; i++) 
		  {
			  if(s.charAt(i).match(/[\u00B7]/)
				  || s.charAt(i).match(/[\u0022]/) || s.charAt(i).match(/[\u0026]/)
				  || s.charAt(i).match(/[\u003E]/) || s.charAt(i).match(/[\u003C]/)//<>
				  || s.charAt(i).match(/[\u005C]/) || s.charAt(i).match(/[\u0027]/)
				  || s.charAt(i).match(/[\u0028]/) || s.charAt(i).match(/[\u0029]/)//()
				  || s.charAt(i).match(/[\u007E]/)//~
				  || s.charAt(i).match(/[\u007B]/) || s.charAt(i).match(/[\u007D]/)//{}
				  || s.charAt(i).match(/[\u0025]/)
				  || s.charAt(i).match(/[\u003A]/) || s.charAt(i).match(/[\u003B]/)//{}
				  || s.charAt(i).match(/[\u002C]/))//%
			  { 
				  return error_msg[12][1]; 
			  }
		  }
		  return true;
	 },
	 
	 'checkPPPspechar':function()
	 {
		  var s = "" + this;
		  for(var i = 0; i < s.length; i++) 
		  {
			  if(s.charAt(i).match(/[\u00B7]/)
				  || s.charAt(i).match(/[\u0022]/) || s.charAt(i).match(/[\u0026]/)
				  || s.charAt(i).match(/[\u003E]/) || s.charAt(i).match(/[\u003C]/)//<>
				  || s.charAt(i).match(/[\u005C]/) || s.charAt(i).match(/[\u0027]/)
				  || s.charAt(i).match(/[\u0028]/) || s.charAt(i).match(/[\u0029]/)//()
				  || s.charAt(i).match(/[\u007B]/) || s.charAt(i).match(/[\u007D]/)//{}
				  || s.charAt(i).match(/[\u0025]/)
				  || s.charAt(i).match(/[\u003A]/) || s.charAt(i).match(/[\u003B]/)//{}
				  || s.charAt(i).match(/[\u002C]/))
			  { 
				  return error_msg[14][1]; 
			  }
		  }
		  return true;

	 },
	 
	 'checkPPPspechar_cn':function()
	 {
	      var s = "" + this;
		  for(var i = 0; i < s.length; i++) 
		  {
			  if(s.charAt(i).match(/[\u0391-\uFFE5]/) || s.charAt(i).match(/[\u00B7]/)
				  || s.charAt(i).match(/[\u0022]/) || s.charAt(i).match(/[\u0026]/)
				  || s.charAt(i).match(/[\u003E]/) || s.charAt(i).match(/[\u003C]/)//<>
				  || s.charAt(i).match(/[\u005C]/) || s.charAt(i).match(/[\u0027]/)
				  || s.charAt(i).match(/[\u0028]/) || s.charAt(i).match(/[\u0029]/)//()
				  || s.charAt(i).match(/[\u007B]/) || s.charAt(i).match(/[\u007D]/)//{}
				  || s.charAt(i).match(/[\u0025]/)
				  || s.charAt(i).match(/[\u003A]/) || s.charAt(i).match(/[\u003B]/)//{}
				  || s.charAt(i).match(/[\u002C]/))//%
			  { 
				  return error_msg[15][1]; 
			  }
		  }
		  return true;

	 },
	 
	 'mail':function()
	 {
	      var reg =  /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		  if(reg.test(this))
		     return true;
		  else
		     return error_msg[0][1];
	 },
	 
	 'mac_addr':function()
	 {
	      var j=0;
		  var macvalue="" + this;
		  var myRE = /[0-9a-fA-F]{12}/;
		  var mactmp="";	
		  
		  if(macvalue.length!=17)
			  return error_msg[0][1];
			  
		  else if(macvalue.length==17){
			  if(macvalue.charAt(2)==':')
			  {
				  for(j=2;j<17;j+=3)
					  {
							  if(macvalue.charAt(j)!=':')
							  {
								  return error_msg[0][1];
							  }
					  }
				  mactmp = macvalue.replace(/:/g,"");
			  }	
			  else if(macvalue.charAt(2)=='-')
			  {
				  for(j=2;j<17;j+=3)
					  {
							  if(macvalue.charAt(j)!='-')
							  {
								  return error_msg[0][1];
							  }
					  }
				  mactmp = macvalue.replace(/-/g,"");
			  }
			  else
				  return error_msg[0][1];			
			  
			  if(mactmp.length != 12 || myRE.test(mactmp)!=true)	
			  {
				  return error_msg[0][1];
			  }		
		  }
		  else
		  {
			  return error_msg[0][1];
		  }
		  return true;
	 
	 }
	 
	 
};




function cbi_validate_form(cbid, optional, type,fieldtitle)
{

	var info = cbi_validate_field(cbid, optional, type,fieldtitle);
	if (typeof(info)==="string")
	{                       
		document.getElementById("error_text").innerHTML=info;
		$("#alert_error").show();
		if($(".set").length > 0){
			  $(".set").css("z-index","1999");
		   }else{
		      $("#bgdiv").show();
		   }
		//$("#bgdiv").show();
		//document.getElementById("bgdiv").style.display="block";
		//document.getElementById("alert_error").style.display="block";
		return false;
	}
	else if (!info)
	{
		alert("error");
		return false;
	}
    return true;
}

function cbi_validate_compile(code)
{
	var pos = 0;
	var esc = false;
	var depth = 0;
	var stack = [ ];

	code += ',';

	for (var i = 0; i < code.length; i++)
	{
		if (esc)
		{
			esc = false;
			continue;
		}

		switch (code.charCodeAt(i))
		{
		case 92://'/'
			esc = true;
			break;

		case 40://'('
		case 44://','
			if (depth <= 0)
			{
				if (pos < i)
				{
					var label = code.substring(pos, i);
						label = label.replace(/\\(.)/g, '$1');
						label = label.replace(/^[ \t]+/g, '');
						label = label.replace(/[ \t]+$/g, '');

					if (label && !isNaN(label))
					{
						stack.push(parseFloat(label));
					}
					else if (label.match(/^(['"]).*\1$/))
					{
						stack.push(label.replace(/^(['"])(.*)\1$/, '$2'));
					}
					else if (typeof cbi_validators[label] == 'function')
					{
						stack.push(cbi_validators[label]);
						stack.push(null);
					}
					else
					{
						throw "Syntax error, unhandled token '"+label+"'";
					}
				}
				pos = i+1;
			}
			depth += (code.charCodeAt(i) == 40);
			break;

		case 41://')'
			if (--depth <= 0)
			{
				if (typeof stack[stack.length-2] != 'function')
					throw "Syntax error, argument list follows non-function";

				stack[stack.length-1] =
					arguments.callee(code.substring(pos, i));

				pos = i+1;
			}
			break;
		}
	}

	return stack;
}

function cbi_validate_field(cbid, optional, type,fieldtitle)
{
    var field = (typeof cbid == "string") ? document.getElementById(cbid) : cbid;
    var vstack; try { vstack = cbi_validate_compile(type); } catch(e) { };

    if (field && vstack && typeof vstack[0] == "function")
    {
        var validator = function()
        {
                var value = (field.options && field.options.selectedIndex > -1)
                    ? field.options[field.options.selectedIndex].value : field.value;
                if (!field.disabled)
                {
                    if ((value.length == 0) && !optional)
                    {
                        return fieldtitle + error_msg[1][1];
                    }  
					if(vstack[1] != null)                
                        var errorinfo = vstack[0].apply(value,vstack[1]);
					else
					    var errorinfo = vstack[0].apply(value);
                    if (!(((value.length == 0) && optional) || !(typeof(errorinfo) === "string")))
                    {
                        return fieldtitle + errorinfo;
                    }
                    
                    if (!(((value.length == 0) && optional) || errorinfo))
                    {
                        return fieldtitle + error_msg[5][1];
                    }
                }
            return true;
        };
		return validator();
	}
}

function input_disable(id,boolen){
	if($("#"+id).is('input')){
	    $("#"+id).attr("disabled",boolen);
	}
	else{
		var $input = $("#"+id+" "+":input");
		$($input).each(function(index, element) {
			$(element).attr("disabled",boolen);
		});
	}
}

/* get network or broadcast address by ip and mask  start*/
function netOrBroadAddr(IP, MASK, SoE)
{
	var IP_AMOUNT_MAX = 256;
	var ip = IP.split(".");
	var mask = MASK.split(".");
	var i;

	for(i=0;i<ip.length;i++)
	{
		/* SoE=0:show this Network IP ; SoE=1:show this Network Broadcast IP */
		if(SoE==1)
		{
			mask[i] = ~mask[i] + IP_AMOUNT_MAX;
			ip[i] = ip[i] | mask[i];
		}
		else
			ip[i] = ip[i] & mask[i];
	}
	return ip.join(".");
}
/* get network or broadcast address by ip and mask  end*/

function verifip(ip)
{
	if(ip.value == "")
		return "";
	
	var arr=ip.value.split(".");
	for(var i=0;i<4;i++)
	{
		if(parseInt(arr[i], 10)!="0")
		{
			arr[i]=arr[i].replace(/\b(0+)/gi,"");
		}
		else
		{
		 	arr[i]=parseInt(arr[i], 10);
		}
	}
	 var ret=arr[0]+"."+arr[1]+"."+arr[2]+"."+arr[3];
	 return ret;
}

