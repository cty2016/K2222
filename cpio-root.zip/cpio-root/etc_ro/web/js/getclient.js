// JavaScript Document
var timeClient;
var timeSpeed;
var timeWire;
function get_client(){
    $.get("goform/formUserNum",
	       function(data,textStatus){
	          $("#clientnum").html(data);
			  timeClient = setTimeout("get_client()",3000);
		   }
	)
}
var up_speed,downspeed;
function get_speed(){
    $.get("goform/formWanPortStatistics",
	       function(data,textStatus){
			   up_speed = (data.txBytes/3).toFixed(2);
			   downspeed = (data.rxBytes/3).toFixed(2);
			   if(up_speed > 1024){
			       up_speed = (up_speed/1024).toFixed(2);
				   if(up_speed > 102400){
					   up_speed = (0/1024).toFixed(2);
					   $("#upspeed").html(up_speed + "KB/S");
				   }else if(up_speed > 1024){
					   up_speed = (up_speed/1024).toFixed(2);
					   $("#upspeed").html(up_speed +"MB/S");
				   }else{
				       $("#upspeed").html(up_speed + "KB/S");
				   }
			   }else{
			       $("#upspeed").html(up_speed +"B/S");
			   }
			   
			   if(downspeed > 1024){
			       downspeed = (downspeed/1024).toFixed(2);
				   if(downspeed > 102400){
					   downspeed = (0/1024).toFixed(2);
					   $("#downspeed").html(downspeed +"KB/S");
				   }else if(downspeed > 1024){
					   downspeed = (downspeed/1024).toFixed(2);
					   $("#downspeed").html(downspeed +"MB/S");
				   }else{
				       $("#downspeed").html(downspeed +"KB/S");
				   }
			   }else{
			       $("#downspeed").html(downspeed +"B/S");
			   }
			   timeSpeed = setTimeout("get_speed()",3000);
		   }
	)
}
function get_ready(){
    $.get("goform/formStatisticsReset",
	       function(data,textStatus){
		       if(data == "SUCCESS")
			      get_speed();
		   }
	)
}

function getWireStatus(){
    $.ajax({
	     type:"GET",
		 url:"/wireStatus.asp?t="+Math.random(),
		 success: function(msg){
			 /*2.4g*/
			 //console.log(msg);
			 msg = JSON.parse(msg);
			// console.log(msg.wireStatus);
			// console.log(msg.inicStatus);
			 if(msg.wireStatus != 1){
			     $("#break24").css("opacity","1");
				 
			 }else{
			     $("#break24").css("opacity","0");
			 }
			 /*5g*/
		     if(msg.inicStatus != 1){
			     $("#break5").css("opacity","1");
			 }else{
			     $("#break5").css("opacity","0");
			 }
			 timeWire = setTimeout("getWireStatus()",3000);
		 },
		 error:function(){
		     //console.log("error");
		 }
	})
}

get_ready();
get_client();
getWireStatus();
