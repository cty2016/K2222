#!/bin/sh 

start() {
    /bin/device_manage 
}

stop() {
    killall device_manage 
}

restart() {
    stop
    start
}

$1
