#!/bin/sh 

start() {
    guest_control &
}

stop() {
    killall guest_control 
}

restart() {
    stop
    start
}

$1
