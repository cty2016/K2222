#!/bin/sh

br0=`brctl show | grep br0 | wc -l`

if [ $br0 -eq 1 ]; then
	ra0=`brctl show | grep ra0 | wc -l`
	if [ $ra0 -eq 0 ]; then
		brctl addif br0 ra0
		
		sleep 2

		ra1=`brctl show | grep ra0 | wc -l`
		if [ $ra1 -eq 0 ]; then
			brctl addif br0 ra0
		fi
	fi
fi
