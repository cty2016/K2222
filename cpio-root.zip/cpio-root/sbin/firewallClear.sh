#!/bin/sh

FILTER="filter"
NAT="nat"
MANGLE="mangle"
INPUT="INPUT"
PREROUTING="PREROUTING"
PORT="30005"
MARKVALUE="0x315"

#storage the chains for tables(filter nat mangle)
fr_filter="/tmp/filter_temp.dat"  
fr_nat="/tmp/nat_temp.dat"
fr_mangle="/tmp/mangle_temp.dat"

clearFilter(){

cat $fr_filter |
while read line
do
    right=${line#* }
    left=${right%% *}
    if [ $left = $INPUT ]; then
	input_num=`iptables -nvL ${INPUT} -t $FILTER | wc -l`
	while [ ${input_num} -gt 3 ]; do
	    input_num=`iptables -nvL ${INPUT} -t $FILTER | wc -l`
	    port=`iptables -nL $INPUT -t $FILTER --line-number | grep $MARKVALUE`
	    if [ "$port" = "" ]; then
		continue 2
	    fi
	    
	    port_nu=${port%% *}
	    temp_num=`expr ${input_num} - 2`
	    i=1
	    while [ ${i} -le $temp_num ]; do
		if [ ${i} -ne $port_nu ]; then
		    iptables -D $INPUT $i -t $FILTER 
		    continue 2
		fi
		i=`expr ${i} + 1`
	    done
	done
    else
	iptables -F ${left} -t filter 1>/dev/null 2>&1
    fi
done

return
}

clearMangle(){
cat $fr_mangle |
while read line
do
    right=${line#* }
    left=${right%% *}
	
    if [ $left = $PREROUTING ] ;then
	input_num=`iptables -nvL ${PREROUTING} -t $MANGLE | wc -l`
    	while [ ${input_num} -gt 3 ]; do
	    input_num=`iptables -nvL ${PREROUTING} -t $MANGLE | wc -l`
	    port=`iptables -nL $PREROUTING -t $MANGLE --line-number | grep $PORT`
	    if [ "$port" = "" ]; then
		continue 2
	    fi
			
	    port_nu=${port%% *}
	    temp_num=`expr ${input_num} - 2`
	    i=1
	    while [ ${i} -le $temp_num ]; do
		if [ ${i} -ne $port_nu ]; then
		    iptables -D $PREROUTING $i -t $MANGLE 
		    continue 2
		fi
		i=`expr ${i} + 1`
	    done
	done
    else
	iptables -F ${left} -t ${MANGLE} 1>/dev/null 2>&1
    fi
done

return
}

clearNat(){
cat $fr_nat |
while read line
do
    right=${line#* }
    left=${right%% *}
    
    if [ $left = $PREROUTING ] ;then
	input_num=`iptables -nvL ${PREROUTING} -t $NAT | wc -l`
	while [ ${input_num} -gt 3 ]; do
	    input_num=`iptables -nvL ${PREROUTING} -t $NAT | wc -l`
	    port=`iptables -nL $PREROUTING -t $NAT --line-number | grep $PORT`
	    if [ "$port" = "" ]; then
		continue 2
	    fi

	    port_nu=${port%% *}
	    temp_num=`expr ${input_num} - 2`
	    i=1
	    while [ ${i} -le $temp_num ]; do
		if [ ${i} -ne $port_nu ]; then
		    iptables -D $PREROUTING $i -t $NAT 
		    continue 2
		fi
		i=`expr ${i} + 1`
	    done
	done
    else
	iptables -F ${left} -t ${NAT} 1>/dev/null 2>&1
    fi
done

return
}

funClearRule(){
#Get the Chains for tables(filter nat mangle)
iptables -L -t $FILTER | grep Chain > $fr_filter
iptables -L -t $NAT | grep Chain > $fr_nat
iptables -L -t $MANGLE | grep Chain > $fr_mangle

clearFilter
clearMangle
clearNat

return
}

clear(){
remote_en=`iptables -nvL -t $NAT | grep $PORT | wc -l`

if [ $remote_en -eq 0 ]
then
	#clear all rules
	iptables -F -t filter 1>/dev/null 2>&1
	iptables -F -t nat 1>/dev/null 2>&1
	iptables -F -t mangle 1>/dev/null 2>&1
else
	funClearRule
fi
}

add(){
wan_dhcp_ip=`nvram get wan_dhcp_ipaddr`
wan_static_ip=`nvram get wan_static_ipaddr`
wan_pppoe_ip=`nvram get wan_pppoe_ipaddr`
wan_proto=`nvram get wan_proto`

remote_en=`iptables -nvL -t $NAT | grep $PORT | wc -l`

if [ $remote_en -eq 0 ]
then
    if [ "${wan_proto}" = "dhcp" ]; then
	wan_ip=${wan_dhcp_ip}
    elif [ "${wan_proto}" = "static" ]; then
	wan_ip=${wan_static_ip}
    else
	wan_ip=${wan_pppoe_ip}
    fi
    iptables -t mangle -A PREROUTING -p tcp --dport 30005 -j MARK --set-mark 789
    iptables -t nat -A PREROUTING -d ${wan_ip} -p tcp -m tcp --dport 30005 -j REDIRECT --to-ports 80
    iptables -t filter -I INPUT -p tcp -m mark --mark 789 --dport 80 -j ACCEPT
fi   
}

$1

