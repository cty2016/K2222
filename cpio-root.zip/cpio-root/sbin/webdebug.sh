#!/bin/sh

if [ "$1" = "" -o "$2" = "" ];then
    echo "Usage: $0 [FTPSERVER] [LOCAL_FILE] [REMOTE_FILE]";
    exit
fi
LOCALNAME=`echo $2|awk -F'\/' '{print $NF}' `
if [ -f "/etc_ro/web/web_in_ram" ];then
    echo "Web already mount to RAM";
else
    echo "Remouting..."
    cp /etc_ro/web/ /var/ -rf
    mount -t ramfs ramfs /etc_ro/web/
    mv /var/web/* /etc_ro/web/
    touch /etc_ro/web/web_in_ram
    echo "remout OK"
fi
echo "Downloading $2 to $LOCALNAME ..."
ftpget $1 /etc_ro/web/$LOCALNAME $2
if [ "$?" == 0 ];then
    echo "Download OK"
else
    echo "Download failed" 
fi
