#!/bin/sh
pppd file /etc/options.pppoe &
