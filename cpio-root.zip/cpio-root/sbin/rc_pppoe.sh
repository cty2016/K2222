#!/bin/sh
echo "----------rc-pppoe--------------"
/bin/rc connect PPPOE
